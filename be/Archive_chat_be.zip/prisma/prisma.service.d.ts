import { INestApplication, OnModuleInit } from '@nestjs/common';
import { PrismaClient } from '../generated/prisma/client';
import 'dotenv/config';
export declare class PrismaService extends PrismaClient implements OnModuleInit {
    constructor();
    onModuleInit(): Promise<void>;
    enableShutdownHooks(app: INestApplication): Promise<void>;
}
