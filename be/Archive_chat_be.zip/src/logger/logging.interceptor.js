"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var LoggingInterceptor_1;
Object.defineProperty(exports, "__esModule", { value: true });
exports.LoggingInterceptor = void 0;
const common_1 = require("@nestjs/common");
const operators_1 = require("rxjs/operators");
const nestjs_pino_1 = require("nestjs-pino");
const REQUEST_ID_HEADER = 'x-request-id';
let LoggingInterceptor = LoggingInterceptor_1 = class LoggingInterceptor {
    logger;
    constructor(logger) {
        this.logger = logger;
        this.logger.setContext(LoggingInterceptor_1.name);
    }
    intercept(context, next) {
        const http = context.switchToHttp();
        const req = http.getRequest();
        const res = http.getResponse();
        const requestId = req.headers[REQUEST_ID_HEADER] ?? crypto.randomUUID();
        req.id = requestId;
        res.setHeader(REQUEST_ID_HEADER, requestId);
        const method = req.method;
        const url = req.originalUrl ?? req.url;
        const start = Date.now();
        return next.handle().pipe((0, operators_1.tap)({
            next: () => {
                const statusCode = res.statusCode;
                const durationMs = Date.now() - start;
                this.logger.fatal({
                    requestId,
                    method,
                    url,
                    statusCode,
                    durationMs,
                }, `${method} ${url} ${statusCode} ${durationMs}ms`);
            },
            error: () => {
                const statusCode = res.statusCode || 500;
                const durationMs = Date.now() - start;
                this.logger.warn({
                    requestId,
                    method,
                    url,
                    statusCode,
                    durationMs,
                }, `${method} ${url} ${statusCode} ${durationMs}ms`);
            },
        }));
    }
};
exports.LoggingInterceptor = LoggingInterceptor;
exports.LoggingInterceptor = LoggingInterceptor = LoggingInterceptor_1 = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [nestjs_pino_1.PinoLogger])
], LoggingInterceptor);
//# sourceMappingURL=logging.interceptor.js.map