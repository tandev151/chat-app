"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.LoggerConfig = void 0;
const VALID_LEVELS = [
    'fatal',
    'error',
    'warn',
    'info',
    'debug',
    'trace',
    'silent',
];
exports.LoggerConfig = {
    isDevelopment() {
        return process.env.NODE_ENV !== 'production';
    },
    getLogLevel() {
        const env = (process.env.LOG_LEVEL ?? '').toLowerCase();
        if (VALID_LEVELS.includes(env)) {
            return env;
        }
        return this.isDevelopment() ? 'debug' : 'info';
    },
    getPinoHttpOptions() {
        const level = this.getLogLevel();
        const transport = this.getPinoTransport();
        return {
            level,
            ...(transport && { transport }),
            autoLogging: false,
            genReqId: (req) => {
                const id = req.headers?.['x-request-id'] ?? crypto.randomUUID();
                req.id = id;
                return id;
            },
        };
    },
    getPinoTransport() {
        if (!this.isDevelopment())
            return undefined;
        return {
            target: 'pino-pretty',
            options: {
                colorize: true,
                translateTime: 'SYS:standard',
                ignore: 'pid,hostname',
            },
        };
    },
};
//# sourceMappingURL=logger.config.js.map