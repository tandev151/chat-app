export declare class LoggerModule {
}
