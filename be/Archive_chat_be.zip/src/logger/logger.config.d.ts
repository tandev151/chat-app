export type LogLevel = 'fatal' | 'error' | 'warn' | 'info' | 'debug' | 'trace' | 'silent';
export declare const LoggerConfig: {
    isDevelopment(): boolean;
    getLogLevel(): LogLevel;
    getPinoHttpOptions(): any;
    getPinoTransport(): import("pino").TransportSingleOptions | undefined;
};
