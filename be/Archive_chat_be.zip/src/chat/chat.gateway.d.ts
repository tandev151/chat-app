import { OnGatewayConnection, OnGatewayDisconnect } from '@nestjs/websockets';
import { JwtService } from '@nestjs/jwt';
import { Server } from 'socket.io';
import { ChannelService } from '../channel/channel.service';
export type NewMessagePayload = {
    id: string;
    content: string;
    userId: string;
    channelId: string;
    createdAt: string;
    user: {
        id: string;
        displayName: string;
    };
};
export declare class ChatGateway implements OnGatewayConnection, OnGatewayDisconnect {
    private readonly jwtService;
    private readonly channelService;
    server: Server;
    private readonly logger;
    constructor(jwtService: JwtService, channelService: ChannelService);
    handleConnection(client: any): Promise<void>;
    handleDisconnect(): void;
    handleJoin(client: any, payload: {
        channelId: string;
    }): Promise<void>;
    broadcastNewMessage(channelId: string, message: NewMessagePayload): void;
}
