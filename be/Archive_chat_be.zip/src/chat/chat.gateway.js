"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var ChatGateway_1;
Object.defineProperty(exports, "__esModule", { value: true });
exports.ChatGateway = void 0;
const websockets_1 = require("@nestjs/websockets");
const common_1 = require("@nestjs/common");
const jwt_1 = require("@nestjs/jwt");
const socket_io_1 = require("socket.io");
const channel_service_1 = require("../channel/channel.service");
const ROOM_PREFIX = 'channel:';
let ChatGateway = ChatGateway_1 = class ChatGateway {
    jwtService;
    channelService;
    server;
    logger = new common_1.Logger(ChatGateway_1.name);
    constructor(jwtService, channelService) {
        this.jwtService = jwtService;
        this.channelService = channelService;
    }
    async handleConnection(client) {
        const token = client.handshake?.auth?.token ?? client.handshake?.query?.token;
        if (!token) {
            this.logger.warn('WS connection rejected: no token');
            client.disconnect();
            return;
        }
        try {
            const payload = this.jwtService.verify(token, {
                secret: process.env.JWT_SECRET_KEY,
            });
            if (payload.type !== 'access' || !payload.userId) {
                client.disconnect();
                return;
            }
            client.data.userId = payload.userId;
        }
        catch {
            this.logger.warn('WS connection rejected: invalid token');
            client.disconnect();
        }
    }
    handleDisconnect() {
        this.logger.debug('Client disconnected');
    }
    async handleJoin(client, payload) {
        const userId = client.data?.userId;
        const channelId = payload?.channelId;
        if (!userId || !channelId)
            return;
        try {
            await this.channelService.ensureUserIsMember(channelId, userId);
            client.join(ROOM_PREFIX + channelId);
            this.logger.debug({ channelId, userId }, 'Client joined channel');
        }
        catch {
            this.logger.debug({ channelId, userId }, 'Join rejected: not a member');
        }
    }
    broadcastNewMessage(channelId, message) {
        this.server.to(ROOM_PREFIX + channelId).emit('message', message);
        this.logger.debug({ channelId, messageId: message.id }, 'Message broadcast to channel');
    }
};
exports.ChatGateway = ChatGateway;
__decorate([
    (0, websockets_1.WebSocketServer)(),
    __metadata("design:type", socket_io_1.Server)
], ChatGateway.prototype, "server", void 0);
__decorate([
    (0, websockets_1.SubscribeMessage)('join'),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, Object]),
    __metadata("design:returntype", Promise)
], ChatGateway.prototype, "handleJoin", null);
exports.ChatGateway = ChatGateway = ChatGateway_1 = __decorate([
    (0, websockets_1.WebSocketGateway)({
        cors: { origin: ['http://localhost:5173', 'http://localhost:3001'] },
        path: '/socket.io',
    }),
    __metadata("design:paramtypes", [jwt_1.JwtService,
        channel_service_1.ChannelService])
], ChatGateway);
//# sourceMappingURL=chat.gateway.js.map