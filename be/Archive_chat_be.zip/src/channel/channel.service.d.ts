import { ChannelType } from 'generated/prisma/client';
import { PrismaService } from 'prisma/prisma.service';
import { PaginationQueryDto } from '../common/dto/pagination-query.dto';
export declare class ChannelService {
    private readonly prisma;
    constructor(prisma: PrismaService);
    private areFriends;
    getOrCreateDirectChannel(userId: string, friendId: string): Promise<{
        id: any;
        type: any;
        createdAt: any;
        friend: {
            id: any;
            displayName: any;
        } | null;
    }>;
    private toDirectChannelResponse;
    getDirectChannels(userId: string, pagination: PaginationQueryDto): Promise<{
        id: string;
        type: ChannelType;
        createdAt: Date;
        updatedAt: Date;
        friend: {
            id: string;
            displayName: string;
        } | null;
        lastMessage: {
            id: string;
            content: string;
            createdAt: Date;
        } | null;
    }[]>;
    getChannelById(channelId: string, userId: string): Promise<{
        id: string;
        type: ChannelType;
        name: string | null;
        createdAt: Date;
        updatedAt: Date;
        members: {
            id: string;
            displayName: string;
        }[];
    }>;
    ensureUserIsMember(channelId: string, userId: string): Promise<void>;
}
