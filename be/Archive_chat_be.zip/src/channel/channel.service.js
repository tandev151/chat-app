"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.ChannelService = void 0;
const common_1 = require("@nestjs/common");
const client_1 = require("../../generated/prisma/client");
const prisma_service_1 = require("../../prisma/prisma.service");
let ChannelService = class ChannelService {
    prisma;
    constructor(prisma) {
        this.prisma = prisma;
    }
    async areFriends(userId, friendId) {
        if (userId === friendId)
            return false;
        const request = await this.prisma.friendShipRequest.findFirst({
            where: {
                status: 'ACCEPTED',
                OR: [
                    { requestUserId: userId, addresseeId: friendId },
                    { requestUserId: friendId, addresseeId: userId },
                ],
            },
        });
        return !!request;
    }
    async getOrCreateDirectChannel(userId, friendId) {
        const friends = await this.areFriends(userId, friendId);
        if (!friends) {
            throw new common_1.ForbiddenException('Chỉ có thể tạo kênh chat với bạn bè. Hai user chưa là bạn.');
        }
        const existing = await this.prisma.channel.findFirst({
            where: {
                type: client_1.ChannelType.DM,
                channelMembers: {
                    every: { userId: { in: [userId, friendId] } },
                },
            },
            include: {
                channelMembers: {
                    include: { user: { select: { id: true, displayName: true } } },
                },
            },
        });
        if (existing && existing.channelMembers.length === 2) {
            return this.toDirectChannelResponse(existing, userId);
        }
        const channel = await this.prisma.channel.create({
            data: {
                type: client_1.ChannelType.DM,
                name: null,
                createdById: userId,
                channelMembers: {
                    create: [{ userId }, { userId: friendId }],
                },
            },
            include: {
                channelMembers: {
                    include: { user: { select: { id: true, displayName: true } } },
                },
            },
        });
        return this.toDirectChannelResponse(channel, userId);
    }
    toDirectChannelResponse(channel, currentUserId) {
        const other = channel.channelMembers.find((m) => m.userId !== currentUserId);
        return {
            id: channel.id,
            type: channel.type,
            createdAt: channel.createdAt,
            friend: other?.user
                ? { id: other.user.id, displayName: other.user.displayName }
                : null,
        };
    }
    async getDirectChannels(userId, pagination) {
        const limit = Math.min(pagination.limit ?? 20, 100);
        const page = Math.max(1, pagination.page ?? 1);
        const skip = (page - 1) * limit;
        const channels = await this.prisma.channel.findMany({
            where: {
                type: client_1.ChannelType.DM,
                channelMembers: { some: { userId } },
            },
            orderBy: { updatedAt: 'desc' },
            skip,
            take: limit,
            include: {
                channelMembers: {
                    include: { user: { select: { id: true, displayName: true } } },
                },
                messages: {
                    orderBy: { createdAt: 'desc' },
                    take: 1,
                    select: { id: true, content: true, createdAt: true },
                },
            },
        });
        return channels.map((ch) => {
            const other = ch.channelMembers.find((m) => m.userId !== userId)?.user;
            const lastMessage = ch.messages[0] ?? null;
            return {
                id: ch.id,
                type: ch.type,
                createdAt: ch.createdAt,
                updatedAt: ch.updatedAt,
                friend: other
                    ? { id: other.id, displayName: other.displayName }
                    : null,
                lastMessage: lastMessage
                    ? {
                        id: lastMessage.id,
                        content: lastMessage.content,
                        createdAt: lastMessage.createdAt,
                    }
                    : null,
            };
        });
    }
    async getChannelById(channelId, userId) {
        const channel = await this.prisma.channel.findUnique({
            where: { id: channelId },
            include: {
                channelMembers: {
                    include: { user: { select: { id: true, displayName: true } } },
                },
            },
        });
        if (!channel) {
            throw new common_1.BadRequestException('Kênh không tồn tại');
        }
        const isMember = channel.channelMembers.some((m) => m.userId === userId);
        if (!isMember) {
            throw new common_1.ForbiddenException('Bạn không phải thành viên kênh này');
        }
        return {
            id: channel.id,
            type: channel.type,
            name: channel.name,
            createdAt: channel.createdAt,
            updatedAt: channel.updatedAt,
            members: channel.channelMembers.map((m) => ({
                id: m.user.id,
                displayName: m.user.displayName,
            })),
        };
    }
    async ensureUserIsMember(channelId, userId) {
        const member = await this.prisma.channelMember.findUnique({
            where: { channelId_userId: { channelId, userId } },
        });
        if (!member) {
            throw new common_1.ForbiddenException('Bạn không phải thành viên kênh này');
        }
    }
};
exports.ChannelService = ChannelService;
exports.ChannelService = ChannelService = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [prisma_service_1.PrismaService])
], ChannelService);
//# sourceMappingURL=channel.service.js.map