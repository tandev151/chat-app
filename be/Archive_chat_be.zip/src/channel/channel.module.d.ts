export declare class ChannelModule {
}
