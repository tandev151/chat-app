import { RequestUser } from '../common/interfaces/request-user.interface';
import { PaginationQueryDto } from '../common/dto/pagination-query.dto';
import { CreateDirectChannelDto } from './dto/create-direct-channel.dto';
import { ChannelService } from './channel.service';
export declare class ChannelController {
    private readonly channelService;
    constructor(channelService: ChannelService);
    createOrGetDirect(user: RequestUser, dto: CreateDirectChannelDto): Promise<{
        id: any;
        type: any;
        createdAt: any;
        friend: {
            id: any;
            displayName: any;
        } | null;
    }>;
    getDirectChannels(user: RequestUser, pagination: PaginationQueryDto): Promise<{
        id: string;
        type: import("../../generated/prisma/enums").ChannelType;
        createdAt: Date;
        updatedAt: Date;
        friend: {
            id: string;
            displayName: string;
        } | null;
        lastMessage: {
            id: string;
            content: string;
            createdAt: Date;
        } | null;
    }[]>;
    getChannel(user: RequestUser, channelId: string): Promise<{
        id: string;
        type: import("../../generated/prisma/enums").ChannelType;
        name: string | null;
        createdAt: Date;
        updatedAt: Date;
        members: {
            id: string;
            displayName: string;
        }[];
    }>;
}
