export declare class CreateDirectChannelDto {
    friendId: string;
}
