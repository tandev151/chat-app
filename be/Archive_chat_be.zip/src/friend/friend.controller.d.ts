import { RequestUser } from '../common/interfaces/request-user.interface';
import { AddFriendDto } from './dto/add-friend.dto';
import { FriendService } from './friend.service';
import { ConfirmFriendDto } from './dto/confirm-friend.dto';
import { PaginationQueryDto } from 'src/common/dto/pagination-query.dto';
export declare class FriendController {
    private readonly friendService;
    constructor(friendService: FriendService);
    getFriends(user: RequestUser): Promise<import("./interface/friend-list.interface").FriendListItem[]>;
    addFriend(user: RequestUser, addFriendDto: AddFriendDto): Promise<{
        id: string;
        createdAt: Date;
        requestUserId: string;
        addresseeId: string;
        status: import("../../generated/prisma/enums").FriendshipRequestStatus;
        respondedAt: Date | null;
    }>;
    confirmFriend(user: RequestUser, confirmFriendDto: ConfirmFriendDto): Promise<{}>;
    getRecommendedFriends(user: RequestUser, paginationQueryDto: PaginationQueryDto): Promise<import("./interface/friend-list.interface").FriendListItem[]>;
    getPendingRequests(user: RequestUser): Promise<import("./interface/friend-list.interface").FriendListItem[]>;
}
