export declare class ConfirmFriendDto {
    friendRequestId: string;
    status: 'accepted' | 'rejected';
}
