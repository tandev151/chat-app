export declare class AddFriendDto {
    addresseeId: string;
}
