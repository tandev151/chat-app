"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.FriendService = void 0;
const common_1 = require("@nestjs/common");
const prisma_service_1 = require("../../prisma/prisma.service");
let FriendService = class FriendService {
    prisma;
    constructor(prisma) {
        this.prisma = prisma;
    }
    async getFriends(userId) {
        const acceptedRequests = await this.prisma.friendShipRequest.findMany({
            where: {
                status: 'ACCEPTED',
                OR: [{ requestUserId: userId }, { addresseeId: userId }],
            },
            include: {
                requester: { select: { id: true, email: true, displayName: true } },
                addressee: { select: { id: true, email: true, displayName: true } },
            },
        });
        return acceptedRequests.map((req) => {
            const friend = req.requestUserId === userId ? req.addressee : req.requester;
            return {
                id: friend.id,
                email: friend.email,
                displayName: friend.displayName,
            };
        });
    }
    async addFriend(requesterId, addFriendDto) {
        const { addresseeId } = addFriendDto;
        if (requesterId === addresseeId) {
            throw new common_1.BadRequestException('Cannot add yourself as a friend');
        }
        const requester = await this.prisma.user.findUnique({
            where: { id: requesterId },
        });
        if (!requester) {
            throw new common_1.BadRequestException('Requester not found');
        }
        const addressee = await this.prisma.user.findUnique({
            where: { id: addresseeId },
        });
        if (!addressee) {
            throw new common_1.BadRequestException('Addressee not found');
        }
        const existingRequest = await this.prisma.friendShipRequest.findFirst({
            where: {
                requestUserId: requester.id,
                addresseeId: addressee.id,
            },
        });
        if (existingRequest) {
            throw new common_1.BadRequestException('Friend request already exists');
        }
        const newRequest = await this.prisma.friendShipRequest.create({
            data: {
                requestUserId: requester.id,
                addresseeId: addressee.id,
            },
        });
        return newRequest;
    }
    async confirmFriend(currentUserId, confirmFriendDto) {
        const { friendRequestId, status } = confirmFriendDto;
        const requester = this.prisma.user.findUnique({
            where: { id: friendRequestId },
        });
        if (!requester) {
            throw new common_1.BadRequestException('Requester not found');
        }
        const request = await this.prisma.friendShipRequest.findFirst({
            where: {
                requestUserId: friendRequestId,
                addresseeId: currentUserId,
            },
        });
        if (!request) {
            throw new common_1.BadRequestException('Friend request not found');
        }
        let updatingResult;
        if (status === 'accepted') {
            updatingResult = await this.prisma.friendShipRequest.update({
                where: { id: request.id },
                data: { status: 'ACCEPTED' },
            });
        }
        else {
            updatingResult = await this.prisma.friendShipRequest.delete({
                where: { id: request.id },
            });
        }
        if (!updatingResult) {
            throw new common_1.BadRequestException('Failed to update friend request');
        }
        return updatingResult;
    }
    async getRecommendedFriends(currentUserId, paginationQueryDto) {
        const { limit, page, orderBy } = paginationQueryDto;
        const users = await this.prisma.user.findMany({
            where: {
                id: { not: currentUserId },
                NOT: {
                    OR: [
                        {
                            friendshipRequestsSent: {
                                some: {
                                    addresseeId: currentUserId,
                                    status: 'ACCEPTED',
                                },
                            },
                        },
                        {
                            friendshipRequestsReceived: {
                                some: {
                                    requestUserId: currentUserId,
                                    status: 'ACCEPTED',
                                },
                            },
                        },
                    ],
                },
                AND: [
                    {
                        NOT: {
                            friendshipRequestsSent: {
                                some: {
                                    addresseeId: currentUserId,
                                    status: 'PENDING',
                                },
                            },
                        },
                    },
                    {
                        NOT: {
                            friendshipRequestsReceived: {
                                some: {
                                    requestUserId: currentUserId,
                                    status: 'PENDING',
                                },
                            },
                        },
                    },
                ],
            },
            select: { id: true, email: true, displayName: true },
            orderBy: { displayName: 'asc' },
            take: 10,
        });
        return users.map((user) => ({
            id: user.id,
            email: user.email,
            displayName: user.displayName,
        }));
    }
    async getPendingRequests(currentUserId) {
        const pendingRequests = await this.prisma.friendShipRequest.findMany({
            where: {
                addresseeId: currentUserId,
                status: 'PENDING',
            },
            include: {
                requester: { select: { id: true, email: true, displayName: true } },
            },
        });
        if (!pendingRequests) {
            return [];
        }
        return pendingRequests.map((req) => ({
            id: req.requester.id,
            email: req.requester.email,
            displayName: req.requester.displayName,
        }));
    }
};
exports.FriendService = FriendService;
exports.FriendService = FriendService = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [prisma_service_1.PrismaService])
], FriendService);
//# sourceMappingURL=friend.service.js.map