export interface FriendListItem {
    id: string;
    email: string;
    displayName: string;
}
