export declare class FriendModule {
}
