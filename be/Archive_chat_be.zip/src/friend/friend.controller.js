"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.FriendController = void 0;
const common_1 = require("@nestjs/common");
const current_user_decorator_1 = require("../common/decorators/current-user.decorator");
const jwt_auth_guard_1 = require("../common/guards/jwt-auth.guard");
const add_friend_dto_1 = require("./dto/add-friend.dto");
const friend_service_1 = require("./friend.service");
const confirm_friend_dto_1 = require("./dto/confirm-friend.dto");
const pagination_query_dto_1 = require("../common/dto/pagination-query.dto");
let FriendController = class FriendController {
    friendService;
    constructor(friendService) {
        this.friendService = friendService;
    }
    async getFriends(user) {
        return this.friendService.getFriends(user.userId);
    }
    async addFriend(user, addFriendDto) {
        return this.friendService.addFriend(user.userId, addFriendDto);
    }
    async confirmFriend(user, confirmFriendDto) {
        return this.friendService.confirmFriend(user.userId, confirmFriendDto);
    }
    async getRecommendedFriends(user, paginationQueryDto) {
        return this.friendService.getRecommendedFriends(user.userId, paginationQueryDto);
    }
    async getPendingRequests(user) {
        return this.friendService.getPendingRequests(user.userId);
    }
};
exports.FriendController = FriendController;
__decorate([
    (0, common_1.Get)('friends'),
    __param(0, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object]),
    __metadata("design:returntype", Promise)
], FriendController.prototype, "getFriends", null);
__decorate([
    (0, common_1.Post)('add'),
    __param(0, (0, current_user_decorator_1.CurrentUser)()),
    __param(1, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, add_friend_dto_1.AddFriendDto]),
    __metadata("design:returntype", Promise)
], FriendController.prototype, "addFriend", null);
__decorate([
    (0, common_1.Post)('confirm'),
    __param(0, (0, current_user_decorator_1.CurrentUser)()),
    __param(1, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, confirm_friend_dto_1.ConfirmFriendDto]),
    __metadata("design:returntype", Promise)
], FriendController.prototype, "confirmFriend", null);
__decorate([
    (0, common_1.Get)('recommended'),
    __param(0, (0, current_user_decorator_1.CurrentUser)()),
    __param(1, (0, common_1.Query)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, pagination_query_dto_1.PaginationQueryDto]),
    __metadata("design:returntype", Promise)
], FriendController.prototype, "getRecommendedFriends", null);
__decorate([
    (0, common_1.Get)('pending'),
    __param(0, (0, current_user_decorator_1.CurrentUser)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object]),
    __metadata("design:returntype", Promise)
], FriendController.prototype, "getPendingRequests", null);
exports.FriendController = FriendController = __decorate([
    (0, common_1.Controller)('friend'),
    (0, common_1.UseGuards)(jwt_auth_guard_1.JwtAuthGuard),
    __metadata("design:paramtypes", [friend_service_1.FriendService])
], FriendController);
//# sourceMappingURL=friend.controller.js.map