import { PrismaService } from 'prisma/prisma.service';
import { AddFriendDto } from './dto/add-friend.dto';
import { ConfirmFriendDto } from './dto/confirm-friend.dto';
import { FriendListItem } from './interface/friend-list.interface';
import { PaginationQueryDto } from 'src/common/dto/pagination-query.dto';
export declare class FriendService {
    private readonly prisma;
    constructor(prisma: PrismaService);
    getFriends(userId: string): Promise<FriendListItem[]>;
    addFriend(requesterId: string, addFriendDto: AddFriendDto): Promise<{
        id: string;
        createdAt: Date;
        requestUserId: string;
        addresseeId: string;
        status: import("../../generated/prisma/enums").FriendshipRequestStatus;
        respondedAt: Date | null;
    }>;
    confirmFriend(currentUserId: string, confirmFriendDto: ConfirmFriendDto): Promise<{}>;
    getRecommendedFriends(currentUserId: string, paginationQueryDto: PaginationQueryDto): Promise<FriendListItem[]>;
    getPendingRequests(currentUserId: string): Promise<FriendListItem[]>;
}
