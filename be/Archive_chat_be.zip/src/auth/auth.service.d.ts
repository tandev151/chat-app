import { LoginDto } from './dto/login.dto';
import { PrismaService } from 'prisma/prisma.service';
import { AuthResponse } from './interface/auth.interface';
import { JwtService } from '@nestjs/jwt';
export declare class AuthService {
    private readonly prisma;
    private readonly jwtService;
    constructor(prisma: PrismaService, jwtService: JwtService);
    login(createAuthDto: LoginDto): Promise<AuthResponse>;
    refreshToken(refreshToken: string): Promise<AuthResponse>;
}
