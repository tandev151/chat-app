import { JwtPayload, JwtUser } from '../interface/auth.interface';
declare const JwtStrategy_base: new (...args: any) => any;
export declare class JwtStrategy extends JwtStrategy_base {
    constructor();
    validate(payload: JwtPayload): JwtUser;
}
export {};
