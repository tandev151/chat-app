export interface AuthResponse {
    accessToken: string;
    expiresIn: number;
    refreshToken: string;
    type: 'bearer';
}
export interface JwtPayload {
    userId: string;
    email?: string;
    type: 'access' | 'refresh';
}
export interface JwtUser {
    userId: string;
    email: string;
}
