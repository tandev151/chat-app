import { PrismaService } from 'prisma/prisma.service';
import { PaginationQueryDto } from '../common/dto/pagination-query.dto';
import { ChatGateway } from '../chat/chat.gateway';
export declare class MessageService {
    private readonly prisma;
    private readonly chatGateway;
    private readonly logger;
    constructor(prisma: PrismaService, chatGateway: ChatGateway);
    createMessage(channelId: string, userId: string, content: string): Promise<{
        id: string;
        content: string;
        userId: string;
        channelId: string;
        createdAt: string;
        user: {
            id: string;
            displayName: string;
        };
    }>;
    getMessages(channelId: string, userId: string, pagination: PaginationQueryDto): Promise<{
        total: number;
        page: number;
        limit: number;
        messages: {
            id: string;
            content: string;
            userId: string;
            createdAt: Date;
            user: {
                id: string;
                displayName: string;
            };
        }[];
    }>;
    private ensureUserIsMember;
}
