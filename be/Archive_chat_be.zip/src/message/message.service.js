"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var MessageService_1;
Object.defineProperty(exports, "__esModule", { value: true });
exports.MessageService = void 0;
const common_1 = require("@nestjs/common");
const prisma_service_1 = require("../../prisma/prisma.service");
const chat_gateway_1 = require("../chat/chat.gateway");
let MessageService = MessageService_1 = class MessageService {
    prisma;
    chatGateway;
    logger = new common_1.Logger(MessageService_1.name);
    constructor(prisma, chatGateway) {
        this.prisma = prisma;
        this.chatGateway = chatGateway;
    }
    async createMessage(channelId, userId, content) {
        await this.ensureUserIsMember(channelId, userId);
        const message = await this.prisma.message.create({
            data: { channelId, userId, content },
            include: {
                user: { select: { id: true, displayName: true } },
            },
        });
        const payload = {
            id: message.id,
            content: message.content,
            userId: message.userId,
            channelId: message.channelId,
            createdAt: message.createdAt.toUTCString(),
            user: message.user,
        };
        this.chatGateway.broadcastNewMessage(channelId, payload);
        this.logger.debug({ channelId, messageId: message.id }, 'Message created and broadcast');
        return payload;
    }
    async getMessages(channelId, userId, pagination) {
        await this.ensureUserIsMember(channelId, userId);
        const limit = Math.min(pagination.limit ?? 20, 100);
        const page = Math.max(1, pagination.page ?? 1);
        const skip = (page - 1) * limit;
        const [messages, total] = await this.prisma.$transaction([
            this.prisma.message.findMany({
                where: { channelId },
                orderBy: { createdAt: 'desc' },
                skip,
                take: limit,
                include: {
                    user: { select: { id: true, displayName: true } },
                },
            }),
            this.prisma.message.count({
                where: {
                    channelId,
                },
            }),
        ]);
        return {
            total,
            page,
            limit,
            messages: messages.map((m) => ({
                id: m.id,
                content: m.content,
                userId: m.userId,
                createdAt: m.createdAt,
                user: m.user,
            })),
        };
    }
    async ensureUserIsMember(channelId, userId) {
        const member = await this.prisma.channelMember.findUnique({
            where: { channelId_userId: { channelId, userId } },
        });
        if (!member) {
            this.logger.warn({ channelId }, 'Channel access denied: not a member');
            throw new common_1.ForbiddenException('Bạn không phải thành viên kênh này');
        }
    }
};
exports.MessageService = MessageService;
exports.MessageService = MessageService = MessageService_1 = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [prisma_service_1.PrismaService,
        chat_gateway_1.ChatGateway])
], MessageService);
//# sourceMappingURL=message.service.js.map