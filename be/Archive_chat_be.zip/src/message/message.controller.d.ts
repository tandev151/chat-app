import { RequestUser } from '../common/interfaces/request-user.interface';
import { PaginationQueryDto } from '../common/dto/pagination-query.dto';
import { SendMessageDto } from './dto/send-message.dto';
import { MessageService } from './message.service';
export declare class MessageController {
    private readonly messageService;
    constructor(messageService: MessageService);
    sendMessage(user: RequestUser, channelId: string, dto: SendMessageDto): Promise<{
        id: string;
        content: string;
        userId: string;
        channelId: string;
        createdAt: string;
        user: {
            id: string;
            displayName: string;
        };
    }>;
    getMessages(user: RequestUser, channelId: string, pagination: PaginationQueryDto): Promise<{
        total: number;
        page: number;
        limit: number;
        messages: {
            id: string;
            content: string;
            userId: string;
            createdAt: Date;
            user: {
                id: string;
                displayName: string;
            };
        }[];
    }>;
}
