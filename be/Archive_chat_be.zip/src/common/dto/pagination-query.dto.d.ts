import { Prisma } from 'generated/prisma/client';
export declare class PaginationQueryDto {
    limit?: number;
    page?: number;
    orderBy?: Prisma.SortOrder;
}
