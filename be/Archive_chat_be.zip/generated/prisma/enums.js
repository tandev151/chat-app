"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.FriendshipRequestStatus = exports.ChannelType = void 0;
exports.ChannelType = {
    DM: 'DM',
    GROUP: 'GROUP'
};
exports.FriendshipRequestStatus = {
    PENDING: 'PENDING',
    ACCEPTED: 'ACCEPTED',
    REJECTED: 'REJECTED',
    CANCELLED: 'CANCELLED',
    EXPIRED: 'EXPIRED'
};
//# sourceMappingURL=enums.js.map