"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
exports.getPrismaClientClass = getPrismaClientClass;
const runtime = __importStar(require("@prisma/client/runtime/client"));
const config = {
    "previewFeatures": [],
    "clientVersion": "7.3.0",
    "engineVersion": "9d6ad21cbbceab97458517b147a6a09ff43aa735",
    "activeProvider": "postgresql",
    "inlineSchema": "// This is your Prisma schema file,\n// learn more about it in the docs: https://pris.ly/d/prisma-schema\n\n// Looking for ways to speed up your queries, or scale easily with your serverless or edge functions?\n// Try Prisma Accelerate: https://pris.ly/cli/accelerate-init\n\ngenerator client {\n  provider = \"prisma-client\"\n  output   = \"../generated/prisma\"\n}\n\ndatasource db {\n  provider = \"postgresql\"\n}\n\nmodel User {\n  id           String    @id @default(uuid())\n  email        String    @unique\n  passwordHash String\n  displayName  String\n  messages     Message[] // 1 user - nhiều message\n  channels     Channel[] @relation(\"UserChannels\") // user tạo ra các channel\n\n  // Friendship requests - GỬI ĐI (tôi là người gửi)\n  friendshipRequestsSent FriendShipRequest[] @relation(\"FriendshipRequestRequester\")\n\n  // Friendship requests - NHẬN ĐƯỢC (tôi là người nhận)\n  friendshipRequestsReceived FriendShipRequest[] @relation(\"FriendshipRequestAddressee\")\n\n  createdAt      DateTime        @default(now())\n  updatedAt      DateTime        @updatedAt\n  channelMembers ChannelMember[]\n}\n\nenum ChannelType {\n  DM\n  GROUP\n}\n\nmodel Channel {\n  id          String      @id @default(uuid())\n  type        ChannelType @default(GROUP)\n  name        String? // optional for DM channels\n  description String?\n  createdBy   User        @relation(\"UserChannels\", fields: [createdById], references: [id])\n  createdById String\n\n  messages Message[] // 1 channel - nhiều message\n\n  createdAt      DateTime        @default(now())\n  updatedAt      DateTime        @updatedAt\n  channelMembers ChannelMember[]\n}\n\nmodel Message {\n  id      String @id @default(uuid())\n  content String\n\n  channel   Channel @relation(fields: [channelId], references: [id])\n  channelId String\n\n  user   User   @relation(fields: [userId], references: [id])\n  userId String\n\n  createdAt DateTime @default(now())\n}\n\nmodel ChannelMember {\n  id String @id @default(uuid())\n\n  channel   Channel @relation(fields: [channelId], references: [id])\n  channelId String\n\n  user   User   @relation(fields: [userId], references: [id])\n  userId String\n\n  joinedAt DateTime @default(now())\n\n  @@unique([channelId, userId]) // 1 user chỉ join 1 lần vào 1 channel\n}\n\nenum FriendshipRequestStatus {\n  PENDING\n  ACCEPTED\n  REJECTED\n  CANCELLED\n  EXPIRED // optional\n}\n\nmodel FriendShipRequest {\n  id String @id @default(uuid())\n\n  requestUserId String\n  addresseeId   String\n\n  requester User @relation(\"FriendshipRequestRequester\", fields: [requestUserId], references: [id])\n  addressee User @relation(\"FriendshipRequestAddressee\", fields: [addresseeId], references: [id])\n\n  status      FriendshipRequestStatus @default(PENDING)\n  createdAt   DateTime                @default(now())\n  respondedAt DateTime?\n\n  @@unique([requestUserId, addresseeId]) // 1 cặp (requester, addressee) chỉ 1 request\n}\n",
    "runtimeDataModel": {
        "models": {},
        "enums": {},
        "types": {}
    }
};
config.runtimeDataModel = JSON.parse("{\"models\":{\"User\":{\"fields\":[{\"name\":\"id\",\"kind\":\"scalar\",\"type\":\"String\"},{\"name\":\"email\",\"kind\":\"scalar\",\"type\":\"String\"},{\"name\":\"passwordHash\",\"kind\":\"scalar\",\"type\":\"String\"},{\"name\":\"displayName\",\"kind\":\"scalar\",\"type\":\"String\"},{\"name\":\"messages\",\"kind\":\"object\",\"type\":\"Message\",\"relationName\":\"MessageToUser\"},{\"name\":\"channels\",\"kind\":\"object\",\"type\":\"Channel\",\"relationName\":\"UserChannels\"},{\"name\":\"friendshipRequestsSent\",\"kind\":\"object\",\"type\":\"FriendShipRequest\",\"relationName\":\"FriendshipRequestRequester\"},{\"name\":\"friendshipRequestsReceived\",\"kind\":\"object\",\"type\":\"FriendShipRequest\",\"relationName\":\"FriendshipRequestAddressee\"},{\"name\":\"createdAt\",\"kind\":\"scalar\",\"type\":\"DateTime\"},{\"name\":\"updatedAt\",\"kind\":\"scalar\",\"type\":\"DateTime\"},{\"name\":\"channelMembers\",\"kind\":\"object\",\"type\":\"ChannelMember\",\"relationName\":\"ChannelMemberToUser\"}],\"dbName\":null},\"Channel\":{\"fields\":[{\"name\":\"id\",\"kind\":\"scalar\",\"type\":\"String\"},{\"name\":\"type\",\"kind\":\"enum\",\"type\":\"ChannelType\"},{\"name\":\"name\",\"kind\":\"scalar\",\"type\":\"String\"},{\"name\":\"description\",\"kind\":\"scalar\",\"type\":\"String\"},{\"name\":\"createdBy\",\"kind\":\"object\",\"type\":\"User\",\"relationName\":\"UserChannels\"},{\"name\":\"createdById\",\"kind\":\"scalar\",\"type\":\"String\"},{\"name\":\"messages\",\"kind\":\"object\",\"type\":\"Message\",\"relationName\":\"ChannelToMessage\"},{\"name\":\"createdAt\",\"kind\":\"scalar\",\"type\":\"DateTime\"},{\"name\":\"updatedAt\",\"kind\":\"scalar\",\"type\":\"DateTime\"},{\"name\":\"channelMembers\",\"kind\":\"object\",\"type\":\"ChannelMember\",\"relationName\":\"ChannelToChannelMember\"}],\"dbName\":null},\"Message\":{\"fields\":[{\"name\":\"id\",\"kind\":\"scalar\",\"type\":\"String\"},{\"name\":\"content\",\"kind\":\"scalar\",\"type\":\"String\"},{\"name\":\"channel\",\"kind\":\"object\",\"type\":\"Channel\",\"relationName\":\"ChannelToMessage\"},{\"name\":\"channelId\",\"kind\":\"scalar\",\"type\":\"String\"},{\"name\":\"user\",\"kind\":\"object\",\"type\":\"User\",\"relationName\":\"MessageToUser\"},{\"name\":\"userId\",\"kind\":\"scalar\",\"type\":\"String\"},{\"name\":\"createdAt\",\"kind\":\"scalar\",\"type\":\"DateTime\"}],\"dbName\":null},\"ChannelMember\":{\"fields\":[{\"name\":\"id\",\"kind\":\"scalar\",\"type\":\"String\"},{\"name\":\"channel\",\"kind\":\"object\",\"type\":\"Channel\",\"relationName\":\"ChannelToChannelMember\"},{\"name\":\"channelId\",\"kind\":\"scalar\",\"type\":\"String\"},{\"name\":\"user\",\"kind\":\"object\",\"type\":\"User\",\"relationName\":\"ChannelMemberToUser\"},{\"name\":\"userId\",\"kind\":\"scalar\",\"type\":\"String\"},{\"name\":\"joinedAt\",\"kind\":\"scalar\",\"type\":\"DateTime\"}],\"dbName\":null},\"FriendShipRequest\":{\"fields\":[{\"name\":\"id\",\"kind\":\"scalar\",\"type\":\"String\"},{\"name\":\"requestUserId\",\"kind\":\"scalar\",\"type\":\"String\"},{\"name\":\"addresseeId\",\"kind\":\"scalar\",\"type\":\"String\"},{\"name\":\"requester\",\"kind\":\"object\",\"type\":\"User\",\"relationName\":\"FriendshipRequestRequester\"},{\"name\":\"addressee\",\"kind\":\"object\",\"type\":\"User\",\"relationName\":\"FriendshipRequestAddressee\"},{\"name\":\"status\",\"kind\":\"enum\",\"type\":\"FriendshipRequestStatus\"},{\"name\":\"createdAt\",\"kind\":\"scalar\",\"type\":\"DateTime\"},{\"name\":\"respondedAt\",\"kind\":\"scalar\",\"type\":\"DateTime\"}],\"dbName\":null}},\"enums\":{},\"types\":{}}");
async function decodeBase64AsWasm(wasmBase64) {
    const { Buffer } = await Promise.resolve().then(() => __importStar(require('node:buffer')));
    const wasmArray = Buffer.from(wasmBase64, 'base64');
    return new WebAssembly.Module(wasmArray);
}
config.compilerWasm = {
    getRuntime: async () => await Promise.resolve().then(() => __importStar(require("@prisma/client/runtime/query_compiler_fast_bg.postgresql.js"))),
    getQueryCompilerWasmModule: async () => {
        const { wasm } = await Promise.resolve().then(() => __importStar(require("@prisma/client/runtime/query_compiler_fast_bg.postgresql.wasm-base64.js")));
        return await decodeBase64AsWasm(wasm);
    },
    importName: "./query_compiler_fast_bg.js"
};
function getPrismaClientClass() {
    return runtime.getPrismaClient(config);
}
//# sourceMappingURL=class.js.map