export declare const ChannelType: {
    readonly DM: "DM";
    readonly GROUP: "GROUP";
};
export type ChannelType = (typeof ChannelType)[keyof typeof ChannelType];
export declare const FriendshipRequestStatus: {
    readonly PENDING: "PENDING";
    readonly ACCEPTED: "ACCEPTED";
    readonly REJECTED: "REJECTED";
    readonly CANCELLED: "CANCELLED";
    readonly EXPIRED: "EXPIRED";
};
export type FriendshipRequestStatus = (typeof FriendshipRequestStatus)[keyof typeof FriendshipRequestStatus];
