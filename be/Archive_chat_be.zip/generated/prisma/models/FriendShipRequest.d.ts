import type * as runtime from "@prisma/client/runtime/client";
import type * as $Enums from "../enums";
import type * as Prisma from "../internal/prismaNamespace";
export type FriendShipRequestModel = runtime.Types.Result.DefaultSelection<Prisma.$FriendShipRequestPayload>;
export type AggregateFriendShipRequest = {
    _count: FriendShipRequestCountAggregateOutputType | null;
    _min: FriendShipRequestMinAggregateOutputType | null;
    _max: FriendShipRequestMaxAggregateOutputType | null;
};
export type FriendShipRequestMinAggregateOutputType = {
    id: string | null;
    requestUserId: string | null;
    addresseeId: string | null;
    status: $Enums.FriendshipRequestStatus | null;
    createdAt: Date | null;
    respondedAt: Date | null;
};
export type FriendShipRequestMaxAggregateOutputType = {
    id: string | null;
    requestUserId: string | null;
    addresseeId: string | null;
    status: $Enums.FriendshipRequestStatus | null;
    createdAt: Date | null;
    respondedAt: Date | null;
};
export type FriendShipRequestCountAggregateOutputType = {
    id: number;
    requestUserId: number;
    addresseeId: number;
    status: number;
    createdAt: number;
    respondedAt: number;
    _all: number;
};
export type FriendShipRequestMinAggregateInputType = {
    id?: true;
    requestUserId?: true;
    addresseeId?: true;
    status?: true;
    createdAt?: true;
    respondedAt?: true;
};
export type FriendShipRequestMaxAggregateInputType = {
    id?: true;
    requestUserId?: true;
    addresseeId?: true;
    status?: true;
    createdAt?: true;
    respondedAt?: true;
};
export type FriendShipRequestCountAggregateInputType = {
    id?: true;
    requestUserId?: true;
    addresseeId?: true;
    status?: true;
    createdAt?: true;
    respondedAt?: true;
    _all?: true;
};
export type FriendShipRequestAggregateArgs<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    where?: Prisma.FriendShipRequestWhereInput;
    orderBy?: Prisma.FriendShipRequestOrderByWithRelationInput | Prisma.FriendShipRequestOrderByWithRelationInput[];
    cursor?: Prisma.FriendShipRequestWhereUniqueInput;
    take?: number;
    skip?: number;
    _count?: true | FriendShipRequestCountAggregateInputType;
    _min?: FriendShipRequestMinAggregateInputType;
    _max?: FriendShipRequestMaxAggregateInputType;
};
export type GetFriendShipRequestAggregateType<T extends FriendShipRequestAggregateArgs> = {
    [P in keyof T & keyof AggregateFriendShipRequest]: P extends '_count' | 'count' ? T[P] extends true ? number : Prisma.GetScalarType<T[P], AggregateFriendShipRequest[P]> : Prisma.GetScalarType<T[P], AggregateFriendShipRequest[P]>;
};
export type FriendShipRequestGroupByArgs<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    where?: Prisma.FriendShipRequestWhereInput;
    orderBy?: Prisma.FriendShipRequestOrderByWithAggregationInput | Prisma.FriendShipRequestOrderByWithAggregationInput[];
    by: Prisma.FriendShipRequestScalarFieldEnum[] | Prisma.FriendShipRequestScalarFieldEnum;
    having?: Prisma.FriendShipRequestScalarWhereWithAggregatesInput;
    take?: number;
    skip?: number;
    _count?: FriendShipRequestCountAggregateInputType | true;
    _min?: FriendShipRequestMinAggregateInputType;
    _max?: FriendShipRequestMaxAggregateInputType;
};
export type FriendShipRequestGroupByOutputType = {
    id: string;
    requestUserId: string;
    addresseeId: string;
    status: $Enums.FriendshipRequestStatus;
    createdAt: Date;
    respondedAt: Date | null;
    _count: FriendShipRequestCountAggregateOutputType | null;
    _min: FriendShipRequestMinAggregateOutputType | null;
    _max: FriendShipRequestMaxAggregateOutputType | null;
};
type GetFriendShipRequestGroupByPayload<T extends FriendShipRequestGroupByArgs> = Prisma.PrismaPromise<Array<Prisma.PickEnumerable<FriendShipRequestGroupByOutputType, T['by']> & {
    [P in ((keyof T) & (keyof FriendShipRequestGroupByOutputType))]: P extends '_count' ? T[P] extends boolean ? number : Prisma.GetScalarType<T[P], FriendShipRequestGroupByOutputType[P]> : Prisma.GetScalarType<T[P], FriendShipRequestGroupByOutputType[P]>;
}>>;
export type FriendShipRequestWhereInput = {
    AND?: Prisma.FriendShipRequestWhereInput | Prisma.FriendShipRequestWhereInput[];
    OR?: Prisma.FriendShipRequestWhereInput[];
    NOT?: Prisma.FriendShipRequestWhereInput | Prisma.FriendShipRequestWhereInput[];
    id?: Prisma.StringFilter<"FriendShipRequest"> | string;
    requestUserId?: Prisma.StringFilter<"FriendShipRequest"> | string;
    addresseeId?: Prisma.StringFilter<"FriendShipRequest"> | string;
    status?: Prisma.EnumFriendshipRequestStatusFilter<"FriendShipRequest"> | $Enums.FriendshipRequestStatus;
    createdAt?: Prisma.DateTimeFilter<"FriendShipRequest"> | Date | string;
    respondedAt?: Prisma.DateTimeNullableFilter<"FriendShipRequest"> | Date | string | null;
    requester?: Prisma.XOR<Prisma.UserScalarRelationFilter, Prisma.UserWhereInput>;
    addressee?: Prisma.XOR<Prisma.UserScalarRelationFilter, Prisma.UserWhereInput>;
};
export type FriendShipRequestOrderByWithRelationInput = {
    id?: Prisma.SortOrder;
    requestUserId?: Prisma.SortOrder;
    addresseeId?: Prisma.SortOrder;
    status?: Prisma.SortOrder;
    createdAt?: Prisma.SortOrder;
    respondedAt?: Prisma.SortOrderInput | Prisma.SortOrder;
    requester?: Prisma.UserOrderByWithRelationInput;
    addressee?: Prisma.UserOrderByWithRelationInput;
};
export type FriendShipRequestWhereUniqueInput = Prisma.AtLeast<{
    id?: string;
    requestUserId_addresseeId?: Prisma.FriendShipRequestRequestUserIdAddresseeIdCompoundUniqueInput;
    AND?: Prisma.FriendShipRequestWhereInput | Prisma.FriendShipRequestWhereInput[];
    OR?: Prisma.FriendShipRequestWhereInput[];
    NOT?: Prisma.FriendShipRequestWhereInput | Prisma.FriendShipRequestWhereInput[];
    requestUserId?: Prisma.StringFilter<"FriendShipRequest"> | string;
    addresseeId?: Prisma.StringFilter<"FriendShipRequest"> | string;
    status?: Prisma.EnumFriendshipRequestStatusFilter<"FriendShipRequest"> | $Enums.FriendshipRequestStatus;
    createdAt?: Prisma.DateTimeFilter<"FriendShipRequest"> | Date | string;
    respondedAt?: Prisma.DateTimeNullableFilter<"FriendShipRequest"> | Date | string | null;
    requester?: Prisma.XOR<Prisma.UserScalarRelationFilter, Prisma.UserWhereInput>;
    addressee?: Prisma.XOR<Prisma.UserScalarRelationFilter, Prisma.UserWhereInput>;
}, "id" | "requestUserId_addresseeId">;
export type FriendShipRequestOrderByWithAggregationInput = {
    id?: Prisma.SortOrder;
    requestUserId?: Prisma.SortOrder;
    addresseeId?: Prisma.SortOrder;
    status?: Prisma.SortOrder;
    createdAt?: Prisma.SortOrder;
    respondedAt?: Prisma.SortOrderInput | Prisma.SortOrder;
    _count?: Prisma.FriendShipRequestCountOrderByAggregateInput;
    _max?: Prisma.FriendShipRequestMaxOrderByAggregateInput;
    _min?: Prisma.FriendShipRequestMinOrderByAggregateInput;
};
export type FriendShipRequestScalarWhereWithAggregatesInput = {
    AND?: Prisma.FriendShipRequestScalarWhereWithAggregatesInput | Prisma.FriendShipRequestScalarWhereWithAggregatesInput[];
    OR?: Prisma.FriendShipRequestScalarWhereWithAggregatesInput[];
    NOT?: Prisma.FriendShipRequestScalarWhereWithAggregatesInput | Prisma.FriendShipRequestScalarWhereWithAggregatesInput[];
    id?: Prisma.StringWithAggregatesFilter<"FriendShipRequest"> | string;
    requestUserId?: Prisma.StringWithAggregatesFilter<"FriendShipRequest"> | string;
    addresseeId?: Prisma.StringWithAggregatesFilter<"FriendShipRequest"> | string;
    status?: Prisma.EnumFriendshipRequestStatusWithAggregatesFilter<"FriendShipRequest"> | $Enums.FriendshipRequestStatus;
    createdAt?: Prisma.DateTimeWithAggregatesFilter<"FriendShipRequest"> | Date | string;
    respondedAt?: Prisma.DateTimeNullableWithAggregatesFilter<"FriendShipRequest"> | Date | string | null;
};
export type FriendShipRequestCreateInput = {
    id?: string;
    status?: $Enums.FriendshipRequestStatus;
    createdAt?: Date | string;
    respondedAt?: Date | string | null;
    requester: Prisma.UserCreateNestedOneWithoutFriendshipRequestsSentInput;
    addressee: Prisma.UserCreateNestedOneWithoutFriendshipRequestsReceivedInput;
};
export type FriendShipRequestUncheckedCreateInput = {
    id?: string;
    requestUserId: string;
    addresseeId: string;
    status?: $Enums.FriendshipRequestStatus;
    createdAt?: Date | string;
    respondedAt?: Date | string | null;
};
export type FriendShipRequestUpdateInput = {
    id?: Prisma.StringFieldUpdateOperationsInput | string;
    status?: Prisma.EnumFriendshipRequestStatusFieldUpdateOperationsInput | $Enums.FriendshipRequestStatus;
    createdAt?: Prisma.DateTimeFieldUpdateOperationsInput | Date | string;
    respondedAt?: Prisma.NullableDateTimeFieldUpdateOperationsInput | Date | string | null;
    requester?: Prisma.UserUpdateOneRequiredWithoutFriendshipRequestsSentNestedInput;
    addressee?: Prisma.UserUpdateOneRequiredWithoutFriendshipRequestsReceivedNestedInput;
};
export type FriendShipRequestUncheckedUpdateInput = {
    id?: Prisma.StringFieldUpdateOperationsInput | string;
    requestUserId?: Prisma.StringFieldUpdateOperationsInput | string;
    addresseeId?: Prisma.StringFieldUpdateOperationsInput | string;
    status?: Prisma.EnumFriendshipRequestStatusFieldUpdateOperationsInput | $Enums.FriendshipRequestStatus;
    createdAt?: Prisma.DateTimeFieldUpdateOperationsInput | Date | string;
    respondedAt?: Prisma.NullableDateTimeFieldUpdateOperationsInput | Date | string | null;
};
export type FriendShipRequestCreateManyInput = {
    id?: string;
    requestUserId: string;
    addresseeId: string;
    status?: $Enums.FriendshipRequestStatus;
    createdAt?: Date | string;
    respondedAt?: Date | string | null;
};
export type FriendShipRequestUpdateManyMutationInput = {
    id?: Prisma.StringFieldUpdateOperationsInput | string;
    status?: Prisma.EnumFriendshipRequestStatusFieldUpdateOperationsInput | $Enums.FriendshipRequestStatus;
    createdAt?: Prisma.DateTimeFieldUpdateOperationsInput | Date | string;
    respondedAt?: Prisma.NullableDateTimeFieldUpdateOperationsInput | Date | string | null;
};
export type FriendShipRequestUncheckedUpdateManyInput = {
    id?: Prisma.StringFieldUpdateOperationsInput | string;
    requestUserId?: Prisma.StringFieldUpdateOperationsInput | string;
    addresseeId?: Prisma.StringFieldUpdateOperationsInput | string;
    status?: Prisma.EnumFriendshipRequestStatusFieldUpdateOperationsInput | $Enums.FriendshipRequestStatus;
    createdAt?: Prisma.DateTimeFieldUpdateOperationsInput | Date | string;
    respondedAt?: Prisma.NullableDateTimeFieldUpdateOperationsInput | Date | string | null;
};
export type FriendShipRequestListRelationFilter = {
    every?: Prisma.FriendShipRequestWhereInput;
    some?: Prisma.FriendShipRequestWhereInput;
    none?: Prisma.FriendShipRequestWhereInput;
};
export type FriendShipRequestOrderByRelationAggregateInput = {
    _count?: Prisma.SortOrder;
};
export type FriendShipRequestRequestUserIdAddresseeIdCompoundUniqueInput = {
    requestUserId: string;
    addresseeId: string;
};
export type FriendShipRequestCountOrderByAggregateInput = {
    id?: Prisma.SortOrder;
    requestUserId?: Prisma.SortOrder;
    addresseeId?: Prisma.SortOrder;
    status?: Prisma.SortOrder;
    createdAt?: Prisma.SortOrder;
    respondedAt?: Prisma.SortOrder;
};
export type FriendShipRequestMaxOrderByAggregateInput = {
    id?: Prisma.SortOrder;
    requestUserId?: Prisma.SortOrder;
    addresseeId?: Prisma.SortOrder;
    status?: Prisma.SortOrder;
    createdAt?: Prisma.SortOrder;
    respondedAt?: Prisma.SortOrder;
};
export type FriendShipRequestMinOrderByAggregateInput = {
    id?: Prisma.SortOrder;
    requestUserId?: Prisma.SortOrder;
    addresseeId?: Prisma.SortOrder;
    status?: Prisma.SortOrder;
    createdAt?: Prisma.SortOrder;
    respondedAt?: Prisma.SortOrder;
};
export type FriendShipRequestCreateNestedManyWithoutRequesterInput = {
    create?: Prisma.XOR<Prisma.FriendShipRequestCreateWithoutRequesterInput, Prisma.FriendShipRequestUncheckedCreateWithoutRequesterInput> | Prisma.FriendShipRequestCreateWithoutRequesterInput[] | Prisma.FriendShipRequestUncheckedCreateWithoutRequesterInput[];
    connectOrCreate?: Prisma.FriendShipRequestCreateOrConnectWithoutRequesterInput | Prisma.FriendShipRequestCreateOrConnectWithoutRequesterInput[];
    createMany?: Prisma.FriendShipRequestCreateManyRequesterInputEnvelope;
    connect?: Prisma.FriendShipRequestWhereUniqueInput | Prisma.FriendShipRequestWhereUniqueInput[];
};
export type FriendShipRequestCreateNestedManyWithoutAddresseeInput = {
    create?: Prisma.XOR<Prisma.FriendShipRequestCreateWithoutAddresseeInput, Prisma.FriendShipRequestUncheckedCreateWithoutAddresseeInput> | Prisma.FriendShipRequestCreateWithoutAddresseeInput[] | Prisma.FriendShipRequestUncheckedCreateWithoutAddresseeInput[];
    connectOrCreate?: Prisma.FriendShipRequestCreateOrConnectWithoutAddresseeInput | Prisma.FriendShipRequestCreateOrConnectWithoutAddresseeInput[];
    createMany?: Prisma.FriendShipRequestCreateManyAddresseeInputEnvelope;
    connect?: Prisma.FriendShipRequestWhereUniqueInput | Prisma.FriendShipRequestWhereUniqueInput[];
};
export type FriendShipRequestUncheckedCreateNestedManyWithoutRequesterInput = {
    create?: Prisma.XOR<Prisma.FriendShipRequestCreateWithoutRequesterInput, Prisma.FriendShipRequestUncheckedCreateWithoutRequesterInput> | Prisma.FriendShipRequestCreateWithoutRequesterInput[] | Prisma.FriendShipRequestUncheckedCreateWithoutRequesterInput[];
    connectOrCreate?: Prisma.FriendShipRequestCreateOrConnectWithoutRequesterInput | Prisma.FriendShipRequestCreateOrConnectWithoutRequesterInput[];
    createMany?: Prisma.FriendShipRequestCreateManyRequesterInputEnvelope;
    connect?: Prisma.FriendShipRequestWhereUniqueInput | Prisma.FriendShipRequestWhereUniqueInput[];
};
export type FriendShipRequestUncheckedCreateNestedManyWithoutAddresseeInput = {
    create?: Prisma.XOR<Prisma.FriendShipRequestCreateWithoutAddresseeInput, Prisma.FriendShipRequestUncheckedCreateWithoutAddresseeInput> | Prisma.FriendShipRequestCreateWithoutAddresseeInput[] | Prisma.FriendShipRequestUncheckedCreateWithoutAddresseeInput[];
    connectOrCreate?: Prisma.FriendShipRequestCreateOrConnectWithoutAddresseeInput | Prisma.FriendShipRequestCreateOrConnectWithoutAddresseeInput[];
    createMany?: Prisma.FriendShipRequestCreateManyAddresseeInputEnvelope;
    connect?: Prisma.FriendShipRequestWhereUniqueInput | Prisma.FriendShipRequestWhereUniqueInput[];
};
export type FriendShipRequestUpdateManyWithoutRequesterNestedInput = {
    create?: Prisma.XOR<Prisma.FriendShipRequestCreateWithoutRequesterInput, Prisma.FriendShipRequestUncheckedCreateWithoutRequesterInput> | Prisma.FriendShipRequestCreateWithoutRequesterInput[] | Prisma.FriendShipRequestUncheckedCreateWithoutRequesterInput[];
    connectOrCreate?: Prisma.FriendShipRequestCreateOrConnectWithoutRequesterInput | Prisma.FriendShipRequestCreateOrConnectWithoutRequesterInput[];
    upsert?: Prisma.FriendShipRequestUpsertWithWhereUniqueWithoutRequesterInput | Prisma.FriendShipRequestUpsertWithWhereUniqueWithoutRequesterInput[];
    createMany?: Prisma.FriendShipRequestCreateManyRequesterInputEnvelope;
    set?: Prisma.FriendShipRequestWhereUniqueInput | Prisma.FriendShipRequestWhereUniqueInput[];
    disconnect?: Prisma.FriendShipRequestWhereUniqueInput | Prisma.FriendShipRequestWhereUniqueInput[];
    delete?: Prisma.FriendShipRequestWhereUniqueInput | Prisma.FriendShipRequestWhereUniqueInput[];
    connect?: Prisma.FriendShipRequestWhereUniqueInput | Prisma.FriendShipRequestWhereUniqueInput[];
    update?: Prisma.FriendShipRequestUpdateWithWhereUniqueWithoutRequesterInput | Prisma.FriendShipRequestUpdateWithWhereUniqueWithoutRequesterInput[];
    updateMany?: Prisma.FriendShipRequestUpdateManyWithWhereWithoutRequesterInput | Prisma.FriendShipRequestUpdateManyWithWhereWithoutRequesterInput[];
    deleteMany?: Prisma.FriendShipRequestScalarWhereInput | Prisma.FriendShipRequestScalarWhereInput[];
};
export type FriendShipRequestUpdateManyWithoutAddresseeNestedInput = {
    create?: Prisma.XOR<Prisma.FriendShipRequestCreateWithoutAddresseeInput, Prisma.FriendShipRequestUncheckedCreateWithoutAddresseeInput> | Prisma.FriendShipRequestCreateWithoutAddresseeInput[] | Prisma.FriendShipRequestUncheckedCreateWithoutAddresseeInput[];
    connectOrCreate?: Prisma.FriendShipRequestCreateOrConnectWithoutAddresseeInput | Prisma.FriendShipRequestCreateOrConnectWithoutAddresseeInput[];
    upsert?: Prisma.FriendShipRequestUpsertWithWhereUniqueWithoutAddresseeInput | Prisma.FriendShipRequestUpsertWithWhereUniqueWithoutAddresseeInput[];
    createMany?: Prisma.FriendShipRequestCreateManyAddresseeInputEnvelope;
    set?: Prisma.FriendShipRequestWhereUniqueInput | Prisma.FriendShipRequestWhereUniqueInput[];
    disconnect?: Prisma.FriendShipRequestWhereUniqueInput | Prisma.FriendShipRequestWhereUniqueInput[];
    delete?: Prisma.FriendShipRequestWhereUniqueInput | Prisma.FriendShipRequestWhereUniqueInput[];
    connect?: Prisma.FriendShipRequestWhereUniqueInput | Prisma.FriendShipRequestWhereUniqueInput[];
    update?: Prisma.FriendShipRequestUpdateWithWhereUniqueWithoutAddresseeInput | Prisma.FriendShipRequestUpdateWithWhereUniqueWithoutAddresseeInput[];
    updateMany?: Prisma.FriendShipRequestUpdateManyWithWhereWithoutAddresseeInput | Prisma.FriendShipRequestUpdateManyWithWhereWithoutAddresseeInput[];
    deleteMany?: Prisma.FriendShipRequestScalarWhereInput | Prisma.FriendShipRequestScalarWhereInput[];
};
export type FriendShipRequestUncheckedUpdateManyWithoutRequesterNestedInput = {
    create?: Prisma.XOR<Prisma.FriendShipRequestCreateWithoutRequesterInput, Prisma.FriendShipRequestUncheckedCreateWithoutRequesterInput> | Prisma.FriendShipRequestCreateWithoutRequesterInput[] | Prisma.FriendShipRequestUncheckedCreateWithoutRequesterInput[];
    connectOrCreate?: Prisma.FriendShipRequestCreateOrConnectWithoutRequesterInput | Prisma.FriendShipRequestCreateOrConnectWithoutRequesterInput[];
    upsert?: Prisma.FriendShipRequestUpsertWithWhereUniqueWithoutRequesterInput | Prisma.FriendShipRequestUpsertWithWhereUniqueWithoutRequesterInput[];
    createMany?: Prisma.FriendShipRequestCreateManyRequesterInputEnvelope;
    set?: Prisma.FriendShipRequestWhereUniqueInput | Prisma.FriendShipRequestWhereUniqueInput[];
    disconnect?: Prisma.FriendShipRequestWhereUniqueInput | Prisma.FriendShipRequestWhereUniqueInput[];
    delete?: Prisma.FriendShipRequestWhereUniqueInput | Prisma.FriendShipRequestWhereUniqueInput[];
    connect?: Prisma.FriendShipRequestWhereUniqueInput | Prisma.FriendShipRequestWhereUniqueInput[];
    update?: Prisma.FriendShipRequestUpdateWithWhereUniqueWithoutRequesterInput | Prisma.FriendShipRequestUpdateWithWhereUniqueWithoutRequesterInput[];
    updateMany?: Prisma.FriendShipRequestUpdateManyWithWhereWithoutRequesterInput | Prisma.FriendShipRequestUpdateManyWithWhereWithoutRequesterInput[];
    deleteMany?: Prisma.FriendShipRequestScalarWhereInput | Prisma.FriendShipRequestScalarWhereInput[];
};
export type FriendShipRequestUncheckedUpdateManyWithoutAddresseeNestedInput = {
    create?: Prisma.XOR<Prisma.FriendShipRequestCreateWithoutAddresseeInput, Prisma.FriendShipRequestUncheckedCreateWithoutAddresseeInput> | Prisma.FriendShipRequestCreateWithoutAddresseeInput[] | Prisma.FriendShipRequestUncheckedCreateWithoutAddresseeInput[];
    connectOrCreate?: Prisma.FriendShipRequestCreateOrConnectWithoutAddresseeInput | Prisma.FriendShipRequestCreateOrConnectWithoutAddresseeInput[];
    upsert?: Prisma.FriendShipRequestUpsertWithWhereUniqueWithoutAddresseeInput | Prisma.FriendShipRequestUpsertWithWhereUniqueWithoutAddresseeInput[];
    createMany?: Prisma.FriendShipRequestCreateManyAddresseeInputEnvelope;
    set?: Prisma.FriendShipRequestWhereUniqueInput | Prisma.FriendShipRequestWhereUniqueInput[];
    disconnect?: Prisma.FriendShipRequestWhereUniqueInput | Prisma.FriendShipRequestWhereUniqueInput[];
    delete?: Prisma.FriendShipRequestWhereUniqueInput | Prisma.FriendShipRequestWhereUniqueInput[];
    connect?: Prisma.FriendShipRequestWhereUniqueInput | Prisma.FriendShipRequestWhereUniqueInput[];
    update?: Prisma.FriendShipRequestUpdateWithWhereUniqueWithoutAddresseeInput | Prisma.FriendShipRequestUpdateWithWhereUniqueWithoutAddresseeInput[];
    updateMany?: Prisma.FriendShipRequestUpdateManyWithWhereWithoutAddresseeInput | Prisma.FriendShipRequestUpdateManyWithWhereWithoutAddresseeInput[];
    deleteMany?: Prisma.FriendShipRequestScalarWhereInput | Prisma.FriendShipRequestScalarWhereInput[];
};
export type EnumFriendshipRequestStatusFieldUpdateOperationsInput = {
    set?: $Enums.FriendshipRequestStatus;
};
export type NullableDateTimeFieldUpdateOperationsInput = {
    set?: Date | string | null;
};
export type FriendShipRequestCreateWithoutRequesterInput = {
    id?: string;
    status?: $Enums.FriendshipRequestStatus;
    createdAt?: Date | string;
    respondedAt?: Date | string | null;
    addressee: Prisma.UserCreateNestedOneWithoutFriendshipRequestsReceivedInput;
};
export type FriendShipRequestUncheckedCreateWithoutRequesterInput = {
    id?: string;
    addresseeId: string;
    status?: $Enums.FriendshipRequestStatus;
    createdAt?: Date | string;
    respondedAt?: Date | string | null;
};
export type FriendShipRequestCreateOrConnectWithoutRequesterInput = {
    where: Prisma.FriendShipRequestWhereUniqueInput;
    create: Prisma.XOR<Prisma.FriendShipRequestCreateWithoutRequesterInput, Prisma.FriendShipRequestUncheckedCreateWithoutRequesterInput>;
};
export type FriendShipRequestCreateManyRequesterInputEnvelope = {
    data: Prisma.FriendShipRequestCreateManyRequesterInput | Prisma.FriendShipRequestCreateManyRequesterInput[];
    skipDuplicates?: boolean;
};
export type FriendShipRequestCreateWithoutAddresseeInput = {
    id?: string;
    status?: $Enums.FriendshipRequestStatus;
    createdAt?: Date | string;
    respondedAt?: Date | string | null;
    requester: Prisma.UserCreateNestedOneWithoutFriendshipRequestsSentInput;
};
export type FriendShipRequestUncheckedCreateWithoutAddresseeInput = {
    id?: string;
    requestUserId: string;
    status?: $Enums.FriendshipRequestStatus;
    createdAt?: Date | string;
    respondedAt?: Date | string | null;
};
export type FriendShipRequestCreateOrConnectWithoutAddresseeInput = {
    where: Prisma.FriendShipRequestWhereUniqueInput;
    create: Prisma.XOR<Prisma.FriendShipRequestCreateWithoutAddresseeInput, Prisma.FriendShipRequestUncheckedCreateWithoutAddresseeInput>;
};
export type FriendShipRequestCreateManyAddresseeInputEnvelope = {
    data: Prisma.FriendShipRequestCreateManyAddresseeInput | Prisma.FriendShipRequestCreateManyAddresseeInput[];
    skipDuplicates?: boolean;
};
export type FriendShipRequestUpsertWithWhereUniqueWithoutRequesterInput = {
    where: Prisma.FriendShipRequestWhereUniqueInput;
    update: Prisma.XOR<Prisma.FriendShipRequestUpdateWithoutRequesterInput, Prisma.FriendShipRequestUncheckedUpdateWithoutRequesterInput>;
    create: Prisma.XOR<Prisma.FriendShipRequestCreateWithoutRequesterInput, Prisma.FriendShipRequestUncheckedCreateWithoutRequesterInput>;
};
export type FriendShipRequestUpdateWithWhereUniqueWithoutRequesterInput = {
    where: Prisma.FriendShipRequestWhereUniqueInput;
    data: Prisma.XOR<Prisma.FriendShipRequestUpdateWithoutRequesterInput, Prisma.FriendShipRequestUncheckedUpdateWithoutRequesterInput>;
};
export type FriendShipRequestUpdateManyWithWhereWithoutRequesterInput = {
    where: Prisma.FriendShipRequestScalarWhereInput;
    data: Prisma.XOR<Prisma.FriendShipRequestUpdateManyMutationInput, Prisma.FriendShipRequestUncheckedUpdateManyWithoutRequesterInput>;
};
export type FriendShipRequestScalarWhereInput = {
    AND?: Prisma.FriendShipRequestScalarWhereInput | Prisma.FriendShipRequestScalarWhereInput[];
    OR?: Prisma.FriendShipRequestScalarWhereInput[];
    NOT?: Prisma.FriendShipRequestScalarWhereInput | Prisma.FriendShipRequestScalarWhereInput[];
    id?: Prisma.StringFilter<"FriendShipRequest"> | string;
    requestUserId?: Prisma.StringFilter<"FriendShipRequest"> | string;
    addresseeId?: Prisma.StringFilter<"FriendShipRequest"> | string;
    status?: Prisma.EnumFriendshipRequestStatusFilter<"FriendShipRequest"> | $Enums.FriendshipRequestStatus;
    createdAt?: Prisma.DateTimeFilter<"FriendShipRequest"> | Date | string;
    respondedAt?: Prisma.DateTimeNullableFilter<"FriendShipRequest"> | Date | string | null;
};
export type FriendShipRequestUpsertWithWhereUniqueWithoutAddresseeInput = {
    where: Prisma.FriendShipRequestWhereUniqueInput;
    update: Prisma.XOR<Prisma.FriendShipRequestUpdateWithoutAddresseeInput, Prisma.FriendShipRequestUncheckedUpdateWithoutAddresseeInput>;
    create: Prisma.XOR<Prisma.FriendShipRequestCreateWithoutAddresseeInput, Prisma.FriendShipRequestUncheckedCreateWithoutAddresseeInput>;
};
export type FriendShipRequestUpdateWithWhereUniqueWithoutAddresseeInput = {
    where: Prisma.FriendShipRequestWhereUniqueInput;
    data: Prisma.XOR<Prisma.FriendShipRequestUpdateWithoutAddresseeInput, Prisma.FriendShipRequestUncheckedUpdateWithoutAddresseeInput>;
};
export type FriendShipRequestUpdateManyWithWhereWithoutAddresseeInput = {
    where: Prisma.FriendShipRequestScalarWhereInput;
    data: Prisma.XOR<Prisma.FriendShipRequestUpdateManyMutationInput, Prisma.FriendShipRequestUncheckedUpdateManyWithoutAddresseeInput>;
};
export type FriendShipRequestCreateManyRequesterInput = {
    id?: string;
    addresseeId: string;
    status?: $Enums.FriendshipRequestStatus;
    createdAt?: Date | string;
    respondedAt?: Date | string | null;
};
export type FriendShipRequestCreateManyAddresseeInput = {
    id?: string;
    requestUserId: string;
    status?: $Enums.FriendshipRequestStatus;
    createdAt?: Date | string;
    respondedAt?: Date | string | null;
};
export type FriendShipRequestUpdateWithoutRequesterInput = {
    id?: Prisma.StringFieldUpdateOperationsInput | string;
    status?: Prisma.EnumFriendshipRequestStatusFieldUpdateOperationsInput | $Enums.FriendshipRequestStatus;
    createdAt?: Prisma.DateTimeFieldUpdateOperationsInput | Date | string;
    respondedAt?: Prisma.NullableDateTimeFieldUpdateOperationsInput | Date | string | null;
    addressee?: Prisma.UserUpdateOneRequiredWithoutFriendshipRequestsReceivedNestedInput;
};
export type FriendShipRequestUncheckedUpdateWithoutRequesterInput = {
    id?: Prisma.StringFieldUpdateOperationsInput | string;
    addresseeId?: Prisma.StringFieldUpdateOperationsInput | string;
    status?: Prisma.EnumFriendshipRequestStatusFieldUpdateOperationsInput | $Enums.FriendshipRequestStatus;
    createdAt?: Prisma.DateTimeFieldUpdateOperationsInput | Date | string;
    respondedAt?: Prisma.NullableDateTimeFieldUpdateOperationsInput | Date | string | null;
};
export type FriendShipRequestUncheckedUpdateManyWithoutRequesterInput = {
    id?: Prisma.StringFieldUpdateOperationsInput | string;
    addresseeId?: Prisma.StringFieldUpdateOperationsInput | string;
    status?: Prisma.EnumFriendshipRequestStatusFieldUpdateOperationsInput | $Enums.FriendshipRequestStatus;
    createdAt?: Prisma.DateTimeFieldUpdateOperationsInput | Date | string;
    respondedAt?: Prisma.NullableDateTimeFieldUpdateOperationsInput | Date | string | null;
};
export type FriendShipRequestUpdateWithoutAddresseeInput = {
    id?: Prisma.StringFieldUpdateOperationsInput | string;
    status?: Prisma.EnumFriendshipRequestStatusFieldUpdateOperationsInput | $Enums.FriendshipRequestStatus;
    createdAt?: Prisma.DateTimeFieldUpdateOperationsInput | Date | string;
    respondedAt?: Prisma.NullableDateTimeFieldUpdateOperationsInput | Date | string | null;
    requester?: Prisma.UserUpdateOneRequiredWithoutFriendshipRequestsSentNestedInput;
};
export type FriendShipRequestUncheckedUpdateWithoutAddresseeInput = {
    id?: Prisma.StringFieldUpdateOperationsInput | string;
    requestUserId?: Prisma.StringFieldUpdateOperationsInput | string;
    status?: Prisma.EnumFriendshipRequestStatusFieldUpdateOperationsInput | $Enums.FriendshipRequestStatus;
    createdAt?: Prisma.DateTimeFieldUpdateOperationsInput | Date | string;
    respondedAt?: Prisma.NullableDateTimeFieldUpdateOperationsInput | Date | string | null;
};
export type FriendShipRequestUncheckedUpdateManyWithoutAddresseeInput = {
    id?: Prisma.StringFieldUpdateOperationsInput | string;
    requestUserId?: Prisma.StringFieldUpdateOperationsInput | string;
    status?: Prisma.EnumFriendshipRequestStatusFieldUpdateOperationsInput | $Enums.FriendshipRequestStatus;
    createdAt?: Prisma.DateTimeFieldUpdateOperationsInput | Date | string;
    respondedAt?: Prisma.NullableDateTimeFieldUpdateOperationsInput | Date | string | null;
};
export type FriendShipRequestSelect<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = runtime.Types.Extensions.GetSelect<{
    id?: boolean;
    requestUserId?: boolean;
    addresseeId?: boolean;
    status?: boolean;
    createdAt?: boolean;
    respondedAt?: boolean;
    requester?: boolean | Prisma.UserDefaultArgs<ExtArgs>;
    addressee?: boolean | Prisma.UserDefaultArgs<ExtArgs>;
}, ExtArgs["result"]["friendShipRequest"]>;
export type FriendShipRequestSelectCreateManyAndReturn<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = runtime.Types.Extensions.GetSelect<{
    id?: boolean;
    requestUserId?: boolean;
    addresseeId?: boolean;
    status?: boolean;
    createdAt?: boolean;
    respondedAt?: boolean;
    requester?: boolean | Prisma.UserDefaultArgs<ExtArgs>;
    addressee?: boolean | Prisma.UserDefaultArgs<ExtArgs>;
}, ExtArgs["result"]["friendShipRequest"]>;
export type FriendShipRequestSelectUpdateManyAndReturn<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = runtime.Types.Extensions.GetSelect<{
    id?: boolean;
    requestUserId?: boolean;
    addresseeId?: boolean;
    status?: boolean;
    createdAt?: boolean;
    respondedAt?: boolean;
    requester?: boolean | Prisma.UserDefaultArgs<ExtArgs>;
    addressee?: boolean | Prisma.UserDefaultArgs<ExtArgs>;
}, ExtArgs["result"]["friendShipRequest"]>;
export type FriendShipRequestSelectScalar = {
    id?: boolean;
    requestUserId?: boolean;
    addresseeId?: boolean;
    status?: boolean;
    createdAt?: boolean;
    respondedAt?: boolean;
};
export type FriendShipRequestOmit<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = runtime.Types.Extensions.GetOmit<"id" | "requestUserId" | "addresseeId" | "status" | "createdAt" | "respondedAt", ExtArgs["result"]["friendShipRequest"]>;
export type FriendShipRequestInclude<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    requester?: boolean | Prisma.UserDefaultArgs<ExtArgs>;
    addressee?: boolean | Prisma.UserDefaultArgs<ExtArgs>;
};
export type FriendShipRequestIncludeCreateManyAndReturn<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    requester?: boolean | Prisma.UserDefaultArgs<ExtArgs>;
    addressee?: boolean | Prisma.UserDefaultArgs<ExtArgs>;
};
export type FriendShipRequestIncludeUpdateManyAndReturn<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    requester?: boolean | Prisma.UserDefaultArgs<ExtArgs>;
    addressee?: boolean | Prisma.UserDefaultArgs<ExtArgs>;
};
export type $FriendShipRequestPayload<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    name: "FriendShipRequest";
    objects: {
        requester: Prisma.$UserPayload<ExtArgs>;
        addressee: Prisma.$UserPayload<ExtArgs>;
    };
    scalars: runtime.Types.Extensions.GetPayloadResult<{
        id: string;
        requestUserId: string;
        addresseeId: string;
        status: $Enums.FriendshipRequestStatus;
        createdAt: Date;
        respondedAt: Date | null;
    }, ExtArgs["result"]["friendShipRequest"]>;
    composites: {};
};
export type FriendShipRequestGetPayload<S extends boolean | null | undefined | FriendShipRequestDefaultArgs> = runtime.Types.Result.GetResult<Prisma.$FriendShipRequestPayload, S>;
export type FriendShipRequestCountArgs<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = Omit<FriendShipRequestFindManyArgs, 'select' | 'include' | 'distinct' | 'omit'> & {
    select?: FriendShipRequestCountAggregateInputType | true;
};
export interface FriendShipRequestDelegate<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs, GlobalOmitOptions = {}> {
    [K: symbol]: {
        types: Prisma.TypeMap<ExtArgs>['model']['FriendShipRequest'];
        meta: {
            name: 'FriendShipRequest';
        };
    };
    findUnique<T extends FriendShipRequestFindUniqueArgs>(args: Prisma.SelectSubset<T, FriendShipRequestFindUniqueArgs<ExtArgs>>): Prisma.Prisma__FriendShipRequestClient<runtime.Types.Result.GetResult<Prisma.$FriendShipRequestPayload<ExtArgs>, T, "findUnique", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>;
    findUniqueOrThrow<T extends FriendShipRequestFindUniqueOrThrowArgs>(args: Prisma.SelectSubset<T, FriendShipRequestFindUniqueOrThrowArgs<ExtArgs>>): Prisma.Prisma__FriendShipRequestClient<runtime.Types.Result.GetResult<Prisma.$FriendShipRequestPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>;
    findFirst<T extends FriendShipRequestFindFirstArgs>(args?: Prisma.SelectSubset<T, FriendShipRequestFindFirstArgs<ExtArgs>>): Prisma.Prisma__FriendShipRequestClient<runtime.Types.Result.GetResult<Prisma.$FriendShipRequestPayload<ExtArgs>, T, "findFirst", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>;
    findFirstOrThrow<T extends FriendShipRequestFindFirstOrThrowArgs>(args?: Prisma.SelectSubset<T, FriendShipRequestFindFirstOrThrowArgs<ExtArgs>>): Prisma.Prisma__FriendShipRequestClient<runtime.Types.Result.GetResult<Prisma.$FriendShipRequestPayload<ExtArgs>, T, "findFirstOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>;
    findMany<T extends FriendShipRequestFindManyArgs>(args?: Prisma.SelectSubset<T, FriendShipRequestFindManyArgs<ExtArgs>>): Prisma.PrismaPromise<runtime.Types.Result.GetResult<Prisma.$FriendShipRequestPayload<ExtArgs>, T, "findMany", GlobalOmitOptions>>;
    create<T extends FriendShipRequestCreateArgs>(args: Prisma.SelectSubset<T, FriendShipRequestCreateArgs<ExtArgs>>): Prisma.Prisma__FriendShipRequestClient<runtime.Types.Result.GetResult<Prisma.$FriendShipRequestPayload<ExtArgs>, T, "create", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>;
    createMany<T extends FriendShipRequestCreateManyArgs>(args?: Prisma.SelectSubset<T, FriendShipRequestCreateManyArgs<ExtArgs>>): Prisma.PrismaPromise<Prisma.BatchPayload>;
    createManyAndReturn<T extends FriendShipRequestCreateManyAndReturnArgs>(args?: Prisma.SelectSubset<T, FriendShipRequestCreateManyAndReturnArgs<ExtArgs>>): Prisma.PrismaPromise<runtime.Types.Result.GetResult<Prisma.$FriendShipRequestPayload<ExtArgs>, T, "createManyAndReturn", GlobalOmitOptions>>;
    delete<T extends FriendShipRequestDeleteArgs>(args: Prisma.SelectSubset<T, FriendShipRequestDeleteArgs<ExtArgs>>): Prisma.Prisma__FriendShipRequestClient<runtime.Types.Result.GetResult<Prisma.$FriendShipRequestPayload<ExtArgs>, T, "delete", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>;
    update<T extends FriendShipRequestUpdateArgs>(args: Prisma.SelectSubset<T, FriendShipRequestUpdateArgs<ExtArgs>>): Prisma.Prisma__FriendShipRequestClient<runtime.Types.Result.GetResult<Prisma.$FriendShipRequestPayload<ExtArgs>, T, "update", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>;
    deleteMany<T extends FriendShipRequestDeleteManyArgs>(args?: Prisma.SelectSubset<T, FriendShipRequestDeleteManyArgs<ExtArgs>>): Prisma.PrismaPromise<Prisma.BatchPayload>;
    updateMany<T extends FriendShipRequestUpdateManyArgs>(args: Prisma.SelectSubset<T, FriendShipRequestUpdateManyArgs<ExtArgs>>): Prisma.PrismaPromise<Prisma.BatchPayload>;
    updateManyAndReturn<T extends FriendShipRequestUpdateManyAndReturnArgs>(args: Prisma.SelectSubset<T, FriendShipRequestUpdateManyAndReturnArgs<ExtArgs>>): Prisma.PrismaPromise<runtime.Types.Result.GetResult<Prisma.$FriendShipRequestPayload<ExtArgs>, T, "updateManyAndReturn", GlobalOmitOptions>>;
    upsert<T extends FriendShipRequestUpsertArgs>(args: Prisma.SelectSubset<T, FriendShipRequestUpsertArgs<ExtArgs>>): Prisma.Prisma__FriendShipRequestClient<runtime.Types.Result.GetResult<Prisma.$FriendShipRequestPayload<ExtArgs>, T, "upsert", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>;
    count<T extends FriendShipRequestCountArgs>(args?: Prisma.Subset<T, FriendShipRequestCountArgs>): Prisma.PrismaPromise<T extends runtime.Types.Utils.Record<'select', any> ? T['select'] extends true ? number : Prisma.GetScalarType<T['select'], FriendShipRequestCountAggregateOutputType> : number>;
    aggregate<T extends FriendShipRequestAggregateArgs>(args: Prisma.Subset<T, FriendShipRequestAggregateArgs>): Prisma.PrismaPromise<GetFriendShipRequestAggregateType<T>>;
    groupBy<T extends FriendShipRequestGroupByArgs, HasSelectOrTake extends Prisma.Or<Prisma.Extends<'skip', Prisma.Keys<T>>, Prisma.Extends<'take', Prisma.Keys<T>>>, OrderByArg extends Prisma.True extends HasSelectOrTake ? {
        orderBy: FriendShipRequestGroupByArgs['orderBy'];
    } : {
        orderBy?: FriendShipRequestGroupByArgs['orderBy'];
    }, OrderFields extends Prisma.ExcludeUnderscoreKeys<Prisma.Keys<Prisma.MaybeTupleToUnion<T['orderBy']>>>, ByFields extends Prisma.MaybeTupleToUnion<T['by']>, ByValid extends Prisma.Has<ByFields, OrderFields>, HavingFields extends Prisma.GetHavingFields<T['having']>, HavingValid extends Prisma.Has<ByFields, HavingFields>, ByEmpty extends T['by'] extends never[] ? Prisma.True : Prisma.False, InputErrors extends ByEmpty extends Prisma.True ? `Error: "by" must not be empty.` : HavingValid extends Prisma.False ? {
        [P in HavingFields]: P extends ByFields ? never : P extends string ? `Error: Field "${P}" used in "having" needs to be provided in "by".` : [
            Error,
            'Field ',
            P,
            ` in "having" needs to be provided in "by"`
        ];
    }[HavingFields] : 'take' extends Prisma.Keys<T> ? 'orderBy' extends Prisma.Keys<T> ? ByValid extends Prisma.True ? {} : {
        [P in OrderFields]: P extends ByFields ? never : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`;
    }[OrderFields] : 'Error: If you provide "take", you also need to provide "orderBy"' : 'skip' extends Prisma.Keys<T> ? 'orderBy' extends Prisma.Keys<T> ? ByValid extends Prisma.True ? {} : {
        [P in OrderFields]: P extends ByFields ? never : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`;
    }[OrderFields] : 'Error: If you provide "skip", you also need to provide "orderBy"' : ByValid extends Prisma.True ? {} : {
        [P in OrderFields]: P extends ByFields ? never : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`;
    }[OrderFields]>(args: Prisma.SubsetIntersection<T, FriendShipRequestGroupByArgs, OrderByArg> & InputErrors): {} extends InputErrors ? GetFriendShipRequestGroupByPayload<T> : Prisma.PrismaPromise<InputErrors>;
    readonly fields: FriendShipRequestFieldRefs;
}
export interface Prisma__FriendShipRequestClient<T, Null = never, ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs, GlobalOmitOptions = {}> extends Prisma.PrismaPromise<T> {
    readonly [Symbol.toStringTag]: "PrismaPromise";
    requester<T extends Prisma.UserDefaultArgs<ExtArgs> = {}>(args?: Prisma.Subset<T, Prisma.UserDefaultArgs<ExtArgs>>): Prisma.Prisma__UserClient<runtime.Types.Result.GetResult<Prisma.$UserPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions> | Null, Null, ExtArgs, GlobalOmitOptions>;
    addressee<T extends Prisma.UserDefaultArgs<ExtArgs> = {}>(args?: Prisma.Subset<T, Prisma.UserDefaultArgs<ExtArgs>>): Prisma.Prisma__UserClient<runtime.Types.Result.GetResult<Prisma.$UserPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions> | Null, Null, ExtArgs, GlobalOmitOptions>;
    then<TResult1 = T, TResult2 = never>(onfulfilled?: ((value: T) => TResult1 | PromiseLike<TResult1>) | undefined | null, onrejected?: ((reason: any) => TResult2 | PromiseLike<TResult2>) | undefined | null): runtime.Types.Utils.JsPromise<TResult1 | TResult2>;
    catch<TResult = never>(onrejected?: ((reason: any) => TResult | PromiseLike<TResult>) | undefined | null): runtime.Types.Utils.JsPromise<T | TResult>;
    finally(onfinally?: (() => void) | undefined | null): runtime.Types.Utils.JsPromise<T>;
}
export interface FriendShipRequestFieldRefs {
    readonly id: Prisma.FieldRef<"FriendShipRequest", 'String'>;
    readonly requestUserId: Prisma.FieldRef<"FriendShipRequest", 'String'>;
    readonly addresseeId: Prisma.FieldRef<"FriendShipRequest", 'String'>;
    readonly status: Prisma.FieldRef<"FriendShipRequest", 'FriendshipRequestStatus'>;
    readonly createdAt: Prisma.FieldRef<"FriendShipRequest", 'DateTime'>;
    readonly respondedAt: Prisma.FieldRef<"FriendShipRequest", 'DateTime'>;
}
export type FriendShipRequestFindUniqueArgs<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    select?: Prisma.FriendShipRequestSelect<ExtArgs> | null;
    omit?: Prisma.FriendShipRequestOmit<ExtArgs> | null;
    include?: Prisma.FriendShipRequestInclude<ExtArgs> | null;
    where: Prisma.FriendShipRequestWhereUniqueInput;
};
export type FriendShipRequestFindUniqueOrThrowArgs<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    select?: Prisma.FriendShipRequestSelect<ExtArgs> | null;
    omit?: Prisma.FriendShipRequestOmit<ExtArgs> | null;
    include?: Prisma.FriendShipRequestInclude<ExtArgs> | null;
    where: Prisma.FriendShipRequestWhereUniqueInput;
};
export type FriendShipRequestFindFirstArgs<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    select?: Prisma.FriendShipRequestSelect<ExtArgs> | null;
    omit?: Prisma.FriendShipRequestOmit<ExtArgs> | null;
    include?: Prisma.FriendShipRequestInclude<ExtArgs> | null;
    where?: Prisma.FriendShipRequestWhereInput;
    orderBy?: Prisma.FriendShipRequestOrderByWithRelationInput | Prisma.FriendShipRequestOrderByWithRelationInput[];
    cursor?: Prisma.FriendShipRequestWhereUniqueInput;
    take?: number;
    skip?: number;
    distinct?: Prisma.FriendShipRequestScalarFieldEnum | Prisma.FriendShipRequestScalarFieldEnum[];
};
export type FriendShipRequestFindFirstOrThrowArgs<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    select?: Prisma.FriendShipRequestSelect<ExtArgs> | null;
    omit?: Prisma.FriendShipRequestOmit<ExtArgs> | null;
    include?: Prisma.FriendShipRequestInclude<ExtArgs> | null;
    where?: Prisma.FriendShipRequestWhereInput;
    orderBy?: Prisma.FriendShipRequestOrderByWithRelationInput | Prisma.FriendShipRequestOrderByWithRelationInput[];
    cursor?: Prisma.FriendShipRequestWhereUniqueInput;
    take?: number;
    skip?: number;
    distinct?: Prisma.FriendShipRequestScalarFieldEnum | Prisma.FriendShipRequestScalarFieldEnum[];
};
export type FriendShipRequestFindManyArgs<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    select?: Prisma.FriendShipRequestSelect<ExtArgs> | null;
    omit?: Prisma.FriendShipRequestOmit<ExtArgs> | null;
    include?: Prisma.FriendShipRequestInclude<ExtArgs> | null;
    where?: Prisma.FriendShipRequestWhereInput;
    orderBy?: Prisma.FriendShipRequestOrderByWithRelationInput | Prisma.FriendShipRequestOrderByWithRelationInput[];
    cursor?: Prisma.FriendShipRequestWhereUniqueInput;
    take?: number;
    skip?: number;
    distinct?: Prisma.FriendShipRequestScalarFieldEnum | Prisma.FriendShipRequestScalarFieldEnum[];
};
export type FriendShipRequestCreateArgs<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    select?: Prisma.FriendShipRequestSelect<ExtArgs> | null;
    omit?: Prisma.FriendShipRequestOmit<ExtArgs> | null;
    include?: Prisma.FriendShipRequestInclude<ExtArgs> | null;
    data: Prisma.XOR<Prisma.FriendShipRequestCreateInput, Prisma.FriendShipRequestUncheckedCreateInput>;
};
export type FriendShipRequestCreateManyArgs<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    data: Prisma.FriendShipRequestCreateManyInput | Prisma.FriendShipRequestCreateManyInput[];
    skipDuplicates?: boolean;
};
export type FriendShipRequestCreateManyAndReturnArgs<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    select?: Prisma.FriendShipRequestSelectCreateManyAndReturn<ExtArgs> | null;
    omit?: Prisma.FriendShipRequestOmit<ExtArgs> | null;
    data: Prisma.FriendShipRequestCreateManyInput | Prisma.FriendShipRequestCreateManyInput[];
    skipDuplicates?: boolean;
    include?: Prisma.FriendShipRequestIncludeCreateManyAndReturn<ExtArgs> | null;
};
export type FriendShipRequestUpdateArgs<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    select?: Prisma.FriendShipRequestSelect<ExtArgs> | null;
    omit?: Prisma.FriendShipRequestOmit<ExtArgs> | null;
    include?: Prisma.FriendShipRequestInclude<ExtArgs> | null;
    data: Prisma.XOR<Prisma.FriendShipRequestUpdateInput, Prisma.FriendShipRequestUncheckedUpdateInput>;
    where: Prisma.FriendShipRequestWhereUniqueInput;
};
export type FriendShipRequestUpdateManyArgs<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    data: Prisma.XOR<Prisma.FriendShipRequestUpdateManyMutationInput, Prisma.FriendShipRequestUncheckedUpdateManyInput>;
    where?: Prisma.FriendShipRequestWhereInput;
    limit?: number;
};
export type FriendShipRequestUpdateManyAndReturnArgs<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    select?: Prisma.FriendShipRequestSelectUpdateManyAndReturn<ExtArgs> | null;
    omit?: Prisma.FriendShipRequestOmit<ExtArgs> | null;
    data: Prisma.XOR<Prisma.FriendShipRequestUpdateManyMutationInput, Prisma.FriendShipRequestUncheckedUpdateManyInput>;
    where?: Prisma.FriendShipRequestWhereInput;
    limit?: number;
    include?: Prisma.FriendShipRequestIncludeUpdateManyAndReturn<ExtArgs> | null;
};
export type FriendShipRequestUpsertArgs<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    select?: Prisma.FriendShipRequestSelect<ExtArgs> | null;
    omit?: Prisma.FriendShipRequestOmit<ExtArgs> | null;
    include?: Prisma.FriendShipRequestInclude<ExtArgs> | null;
    where: Prisma.FriendShipRequestWhereUniqueInput;
    create: Prisma.XOR<Prisma.FriendShipRequestCreateInput, Prisma.FriendShipRequestUncheckedCreateInput>;
    update: Prisma.XOR<Prisma.FriendShipRequestUpdateInput, Prisma.FriendShipRequestUncheckedUpdateInput>;
};
export type FriendShipRequestDeleteArgs<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    select?: Prisma.FriendShipRequestSelect<ExtArgs> | null;
    omit?: Prisma.FriendShipRequestOmit<ExtArgs> | null;
    include?: Prisma.FriendShipRequestInclude<ExtArgs> | null;
    where: Prisma.FriendShipRequestWhereUniqueInput;
};
export type FriendShipRequestDeleteManyArgs<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    where?: Prisma.FriendShipRequestWhereInput;
    limit?: number;
};
export type FriendShipRequestDefaultArgs<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    select?: Prisma.FriendShipRequestSelect<ExtArgs> | null;
    omit?: Prisma.FriendShipRequestOmit<ExtArgs> | null;
    include?: Prisma.FriendShipRequestInclude<ExtArgs> | null;
};
export {};
