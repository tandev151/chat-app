import type * as runtime from "@prisma/client/runtime/client";
import type * as Prisma from "../internal/prismaNamespace";
export type UserModel = runtime.Types.Result.DefaultSelection<Prisma.$UserPayload>;
export type AggregateUser = {
    _count: UserCountAggregateOutputType | null;
    _min: UserMinAggregateOutputType | null;
    _max: UserMaxAggregateOutputType | null;
};
export type UserMinAggregateOutputType = {
    id: string | null;
    email: string | null;
    passwordHash: string | null;
    displayName: string | null;
    createdAt: Date | null;
    updatedAt: Date | null;
};
export type UserMaxAggregateOutputType = {
    id: string | null;
    email: string | null;
    passwordHash: string | null;
    displayName: string | null;
    createdAt: Date | null;
    updatedAt: Date | null;
};
export type UserCountAggregateOutputType = {
    id: number;
    email: number;
    passwordHash: number;
    displayName: number;
    createdAt: number;
    updatedAt: number;
    _all: number;
};
export type UserMinAggregateInputType = {
    id?: true;
    email?: true;
    passwordHash?: true;
    displayName?: true;
    createdAt?: true;
    updatedAt?: true;
};
export type UserMaxAggregateInputType = {
    id?: true;
    email?: true;
    passwordHash?: true;
    displayName?: true;
    createdAt?: true;
    updatedAt?: true;
};
export type UserCountAggregateInputType = {
    id?: true;
    email?: true;
    passwordHash?: true;
    displayName?: true;
    createdAt?: true;
    updatedAt?: true;
    _all?: true;
};
export type UserAggregateArgs<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    where?: Prisma.UserWhereInput;
    orderBy?: Prisma.UserOrderByWithRelationInput | Prisma.UserOrderByWithRelationInput[];
    cursor?: Prisma.UserWhereUniqueInput;
    take?: number;
    skip?: number;
    _count?: true | UserCountAggregateInputType;
    _min?: UserMinAggregateInputType;
    _max?: UserMaxAggregateInputType;
};
export type GetUserAggregateType<T extends UserAggregateArgs> = {
    [P in keyof T & keyof AggregateUser]: P extends '_count' | 'count' ? T[P] extends true ? number : Prisma.GetScalarType<T[P], AggregateUser[P]> : Prisma.GetScalarType<T[P], AggregateUser[P]>;
};
export type UserGroupByArgs<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    where?: Prisma.UserWhereInput;
    orderBy?: Prisma.UserOrderByWithAggregationInput | Prisma.UserOrderByWithAggregationInput[];
    by: Prisma.UserScalarFieldEnum[] | Prisma.UserScalarFieldEnum;
    having?: Prisma.UserScalarWhereWithAggregatesInput;
    take?: number;
    skip?: number;
    _count?: UserCountAggregateInputType | true;
    _min?: UserMinAggregateInputType;
    _max?: UserMaxAggregateInputType;
};
export type UserGroupByOutputType = {
    id: string;
    email: string;
    passwordHash: string;
    displayName: string;
    createdAt: Date;
    updatedAt: Date;
    _count: UserCountAggregateOutputType | null;
    _min: UserMinAggregateOutputType | null;
    _max: UserMaxAggregateOutputType | null;
};
type GetUserGroupByPayload<T extends UserGroupByArgs> = Prisma.PrismaPromise<Array<Prisma.PickEnumerable<UserGroupByOutputType, T['by']> & {
    [P in ((keyof T) & (keyof UserGroupByOutputType))]: P extends '_count' ? T[P] extends boolean ? number : Prisma.GetScalarType<T[P], UserGroupByOutputType[P]> : Prisma.GetScalarType<T[P], UserGroupByOutputType[P]>;
}>>;
export type UserWhereInput = {
    AND?: Prisma.UserWhereInput | Prisma.UserWhereInput[];
    OR?: Prisma.UserWhereInput[];
    NOT?: Prisma.UserWhereInput | Prisma.UserWhereInput[];
    id?: Prisma.StringFilter<"User"> | string;
    email?: Prisma.StringFilter<"User"> | string;
    passwordHash?: Prisma.StringFilter<"User"> | string;
    displayName?: Prisma.StringFilter<"User"> | string;
    createdAt?: Prisma.DateTimeFilter<"User"> | Date | string;
    updatedAt?: Prisma.DateTimeFilter<"User"> | Date | string;
    messages?: Prisma.MessageListRelationFilter;
    channels?: Prisma.ChannelListRelationFilter;
    friendshipRequestsSent?: Prisma.FriendShipRequestListRelationFilter;
    friendshipRequestsReceived?: Prisma.FriendShipRequestListRelationFilter;
    channelMembers?: Prisma.ChannelMemberListRelationFilter;
};
export type UserOrderByWithRelationInput = {
    id?: Prisma.SortOrder;
    email?: Prisma.SortOrder;
    passwordHash?: Prisma.SortOrder;
    displayName?: Prisma.SortOrder;
    createdAt?: Prisma.SortOrder;
    updatedAt?: Prisma.SortOrder;
    messages?: Prisma.MessageOrderByRelationAggregateInput;
    channels?: Prisma.ChannelOrderByRelationAggregateInput;
    friendshipRequestsSent?: Prisma.FriendShipRequestOrderByRelationAggregateInput;
    friendshipRequestsReceived?: Prisma.FriendShipRequestOrderByRelationAggregateInput;
    channelMembers?: Prisma.ChannelMemberOrderByRelationAggregateInput;
};
export type UserWhereUniqueInput = Prisma.AtLeast<{
    id?: string;
    email?: string;
    AND?: Prisma.UserWhereInput | Prisma.UserWhereInput[];
    OR?: Prisma.UserWhereInput[];
    NOT?: Prisma.UserWhereInput | Prisma.UserWhereInput[];
    passwordHash?: Prisma.StringFilter<"User"> | string;
    displayName?: Prisma.StringFilter<"User"> | string;
    createdAt?: Prisma.DateTimeFilter<"User"> | Date | string;
    updatedAt?: Prisma.DateTimeFilter<"User"> | Date | string;
    messages?: Prisma.MessageListRelationFilter;
    channels?: Prisma.ChannelListRelationFilter;
    friendshipRequestsSent?: Prisma.FriendShipRequestListRelationFilter;
    friendshipRequestsReceived?: Prisma.FriendShipRequestListRelationFilter;
    channelMembers?: Prisma.ChannelMemberListRelationFilter;
}, "id" | "email">;
export type UserOrderByWithAggregationInput = {
    id?: Prisma.SortOrder;
    email?: Prisma.SortOrder;
    passwordHash?: Prisma.SortOrder;
    displayName?: Prisma.SortOrder;
    createdAt?: Prisma.SortOrder;
    updatedAt?: Prisma.SortOrder;
    _count?: Prisma.UserCountOrderByAggregateInput;
    _max?: Prisma.UserMaxOrderByAggregateInput;
    _min?: Prisma.UserMinOrderByAggregateInput;
};
export type UserScalarWhereWithAggregatesInput = {
    AND?: Prisma.UserScalarWhereWithAggregatesInput | Prisma.UserScalarWhereWithAggregatesInput[];
    OR?: Prisma.UserScalarWhereWithAggregatesInput[];
    NOT?: Prisma.UserScalarWhereWithAggregatesInput | Prisma.UserScalarWhereWithAggregatesInput[];
    id?: Prisma.StringWithAggregatesFilter<"User"> | string;
    email?: Prisma.StringWithAggregatesFilter<"User"> | string;
    passwordHash?: Prisma.StringWithAggregatesFilter<"User"> | string;
    displayName?: Prisma.StringWithAggregatesFilter<"User"> | string;
    createdAt?: Prisma.DateTimeWithAggregatesFilter<"User"> | Date | string;
    updatedAt?: Prisma.DateTimeWithAggregatesFilter<"User"> | Date | string;
};
export type UserCreateInput = {
    id?: string;
    email: string;
    passwordHash: string;
    displayName: string;
    createdAt?: Date | string;
    updatedAt?: Date | string;
    messages?: Prisma.MessageCreateNestedManyWithoutUserInput;
    channels?: Prisma.ChannelCreateNestedManyWithoutCreatedByInput;
    friendshipRequestsSent?: Prisma.FriendShipRequestCreateNestedManyWithoutRequesterInput;
    friendshipRequestsReceived?: Prisma.FriendShipRequestCreateNestedManyWithoutAddresseeInput;
    channelMembers?: Prisma.ChannelMemberCreateNestedManyWithoutUserInput;
};
export type UserUncheckedCreateInput = {
    id?: string;
    email: string;
    passwordHash: string;
    displayName: string;
    createdAt?: Date | string;
    updatedAt?: Date | string;
    messages?: Prisma.MessageUncheckedCreateNestedManyWithoutUserInput;
    channels?: Prisma.ChannelUncheckedCreateNestedManyWithoutCreatedByInput;
    friendshipRequestsSent?: Prisma.FriendShipRequestUncheckedCreateNestedManyWithoutRequesterInput;
    friendshipRequestsReceived?: Prisma.FriendShipRequestUncheckedCreateNestedManyWithoutAddresseeInput;
    channelMembers?: Prisma.ChannelMemberUncheckedCreateNestedManyWithoutUserInput;
};
export type UserUpdateInput = {
    id?: Prisma.StringFieldUpdateOperationsInput | string;
    email?: Prisma.StringFieldUpdateOperationsInput | string;
    passwordHash?: Prisma.StringFieldUpdateOperationsInput | string;
    displayName?: Prisma.StringFieldUpdateOperationsInput | string;
    createdAt?: Prisma.DateTimeFieldUpdateOperationsInput | Date | string;
    updatedAt?: Prisma.DateTimeFieldUpdateOperationsInput | Date | string;
    messages?: Prisma.MessageUpdateManyWithoutUserNestedInput;
    channels?: Prisma.ChannelUpdateManyWithoutCreatedByNestedInput;
    friendshipRequestsSent?: Prisma.FriendShipRequestUpdateManyWithoutRequesterNestedInput;
    friendshipRequestsReceived?: Prisma.FriendShipRequestUpdateManyWithoutAddresseeNestedInput;
    channelMembers?: Prisma.ChannelMemberUpdateManyWithoutUserNestedInput;
};
export type UserUncheckedUpdateInput = {
    id?: Prisma.StringFieldUpdateOperationsInput | string;
    email?: Prisma.StringFieldUpdateOperationsInput | string;
    passwordHash?: Prisma.StringFieldUpdateOperationsInput | string;
    displayName?: Prisma.StringFieldUpdateOperationsInput | string;
    createdAt?: Prisma.DateTimeFieldUpdateOperationsInput | Date | string;
    updatedAt?: Prisma.DateTimeFieldUpdateOperationsInput | Date | string;
    messages?: Prisma.MessageUncheckedUpdateManyWithoutUserNestedInput;
    channels?: Prisma.ChannelUncheckedUpdateManyWithoutCreatedByNestedInput;
    friendshipRequestsSent?: Prisma.FriendShipRequestUncheckedUpdateManyWithoutRequesterNestedInput;
    friendshipRequestsReceived?: Prisma.FriendShipRequestUncheckedUpdateManyWithoutAddresseeNestedInput;
    channelMembers?: Prisma.ChannelMemberUncheckedUpdateManyWithoutUserNestedInput;
};
export type UserCreateManyInput = {
    id?: string;
    email: string;
    passwordHash: string;
    displayName: string;
    createdAt?: Date | string;
    updatedAt?: Date | string;
};
export type UserUpdateManyMutationInput = {
    id?: Prisma.StringFieldUpdateOperationsInput | string;
    email?: Prisma.StringFieldUpdateOperationsInput | string;
    passwordHash?: Prisma.StringFieldUpdateOperationsInput | string;
    displayName?: Prisma.StringFieldUpdateOperationsInput | string;
    createdAt?: Prisma.DateTimeFieldUpdateOperationsInput | Date | string;
    updatedAt?: Prisma.DateTimeFieldUpdateOperationsInput | Date | string;
};
export type UserUncheckedUpdateManyInput = {
    id?: Prisma.StringFieldUpdateOperationsInput | string;
    email?: Prisma.StringFieldUpdateOperationsInput | string;
    passwordHash?: Prisma.StringFieldUpdateOperationsInput | string;
    displayName?: Prisma.StringFieldUpdateOperationsInput | string;
    createdAt?: Prisma.DateTimeFieldUpdateOperationsInput | Date | string;
    updatedAt?: Prisma.DateTimeFieldUpdateOperationsInput | Date | string;
};
export type UserCountOrderByAggregateInput = {
    id?: Prisma.SortOrder;
    email?: Prisma.SortOrder;
    passwordHash?: Prisma.SortOrder;
    displayName?: Prisma.SortOrder;
    createdAt?: Prisma.SortOrder;
    updatedAt?: Prisma.SortOrder;
};
export type UserMaxOrderByAggregateInput = {
    id?: Prisma.SortOrder;
    email?: Prisma.SortOrder;
    passwordHash?: Prisma.SortOrder;
    displayName?: Prisma.SortOrder;
    createdAt?: Prisma.SortOrder;
    updatedAt?: Prisma.SortOrder;
};
export type UserMinOrderByAggregateInput = {
    id?: Prisma.SortOrder;
    email?: Prisma.SortOrder;
    passwordHash?: Prisma.SortOrder;
    displayName?: Prisma.SortOrder;
    createdAt?: Prisma.SortOrder;
    updatedAt?: Prisma.SortOrder;
};
export type UserScalarRelationFilter = {
    is?: Prisma.UserWhereInput;
    isNot?: Prisma.UserWhereInput;
};
export type StringFieldUpdateOperationsInput = {
    set?: string;
};
export type DateTimeFieldUpdateOperationsInput = {
    set?: Date | string;
};
export type UserCreateNestedOneWithoutChannelsInput = {
    create?: Prisma.XOR<Prisma.UserCreateWithoutChannelsInput, Prisma.UserUncheckedCreateWithoutChannelsInput>;
    connectOrCreate?: Prisma.UserCreateOrConnectWithoutChannelsInput;
    connect?: Prisma.UserWhereUniqueInput;
};
export type UserUpdateOneRequiredWithoutChannelsNestedInput = {
    create?: Prisma.XOR<Prisma.UserCreateWithoutChannelsInput, Prisma.UserUncheckedCreateWithoutChannelsInput>;
    connectOrCreate?: Prisma.UserCreateOrConnectWithoutChannelsInput;
    upsert?: Prisma.UserUpsertWithoutChannelsInput;
    connect?: Prisma.UserWhereUniqueInput;
    update?: Prisma.XOR<Prisma.XOR<Prisma.UserUpdateToOneWithWhereWithoutChannelsInput, Prisma.UserUpdateWithoutChannelsInput>, Prisma.UserUncheckedUpdateWithoutChannelsInput>;
};
export type UserCreateNestedOneWithoutMessagesInput = {
    create?: Prisma.XOR<Prisma.UserCreateWithoutMessagesInput, Prisma.UserUncheckedCreateWithoutMessagesInput>;
    connectOrCreate?: Prisma.UserCreateOrConnectWithoutMessagesInput;
    connect?: Prisma.UserWhereUniqueInput;
};
export type UserUpdateOneRequiredWithoutMessagesNestedInput = {
    create?: Prisma.XOR<Prisma.UserCreateWithoutMessagesInput, Prisma.UserUncheckedCreateWithoutMessagesInput>;
    connectOrCreate?: Prisma.UserCreateOrConnectWithoutMessagesInput;
    upsert?: Prisma.UserUpsertWithoutMessagesInput;
    connect?: Prisma.UserWhereUniqueInput;
    update?: Prisma.XOR<Prisma.XOR<Prisma.UserUpdateToOneWithWhereWithoutMessagesInput, Prisma.UserUpdateWithoutMessagesInput>, Prisma.UserUncheckedUpdateWithoutMessagesInput>;
};
export type UserCreateNestedOneWithoutChannelMembersInput = {
    create?: Prisma.XOR<Prisma.UserCreateWithoutChannelMembersInput, Prisma.UserUncheckedCreateWithoutChannelMembersInput>;
    connectOrCreate?: Prisma.UserCreateOrConnectWithoutChannelMembersInput;
    connect?: Prisma.UserWhereUniqueInput;
};
export type UserUpdateOneRequiredWithoutChannelMembersNestedInput = {
    create?: Prisma.XOR<Prisma.UserCreateWithoutChannelMembersInput, Prisma.UserUncheckedCreateWithoutChannelMembersInput>;
    connectOrCreate?: Prisma.UserCreateOrConnectWithoutChannelMembersInput;
    upsert?: Prisma.UserUpsertWithoutChannelMembersInput;
    connect?: Prisma.UserWhereUniqueInput;
    update?: Prisma.XOR<Prisma.XOR<Prisma.UserUpdateToOneWithWhereWithoutChannelMembersInput, Prisma.UserUpdateWithoutChannelMembersInput>, Prisma.UserUncheckedUpdateWithoutChannelMembersInput>;
};
export type UserCreateNestedOneWithoutFriendshipRequestsSentInput = {
    create?: Prisma.XOR<Prisma.UserCreateWithoutFriendshipRequestsSentInput, Prisma.UserUncheckedCreateWithoutFriendshipRequestsSentInput>;
    connectOrCreate?: Prisma.UserCreateOrConnectWithoutFriendshipRequestsSentInput;
    connect?: Prisma.UserWhereUniqueInput;
};
export type UserCreateNestedOneWithoutFriendshipRequestsReceivedInput = {
    create?: Prisma.XOR<Prisma.UserCreateWithoutFriendshipRequestsReceivedInput, Prisma.UserUncheckedCreateWithoutFriendshipRequestsReceivedInput>;
    connectOrCreate?: Prisma.UserCreateOrConnectWithoutFriendshipRequestsReceivedInput;
    connect?: Prisma.UserWhereUniqueInput;
};
export type UserUpdateOneRequiredWithoutFriendshipRequestsSentNestedInput = {
    create?: Prisma.XOR<Prisma.UserCreateWithoutFriendshipRequestsSentInput, Prisma.UserUncheckedCreateWithoutFriendshipRequestsSentInput>;
    connectOrCreate?: Prisma.UserCreateOrConnectWithoutFriendshipRequestsSentInput;
    upsert?: Prisma.UserUpsertWithoutFriendshipRequestsSentInput;
    connect?: Prisma.UserWhereUniqueInput;
    update?: Prisma.XOR<Prisma.XOR<Prisma.UserUpdateToOneWithWhereWithoutFriendshipRequestsSentInput, Prisma.UserUpdateWithoutFriendshipRequestsSentInput>, Prisma.UserUncheckedUpdateWithoutFriendshipRequestsSentInput>;
};
export type UserUpdateOneRequiredWithoutFriendshipRequestsReceivedNestedInput = {
    create?: Prisma.XOR<Prisma.UserCreateWithoutFriendshipRequestsReceivedInput, Prisma.UserUncheckedCreateWithoutFriendshipRequestsReceivedInput>;
    connectOrCreate?: Prisma.UserCreateOrConnectWithoutFriendshipRequestsReceivedInput;
    upsert?: Prisma.UserUpsertWithoutFriendshipRequestsReceivedInput;
    connect?: Prisma.UserWhereUniqueInput;
    update?: Prisma.XOR<Prisma.XOR<Prisma.UserUpdateToOneWithWhereWithoutFriendshipRequestsReceivedInput, Prisma.UserUpdateWithoutFriendshipRequestsReceivedInput>, Prisma.UserUncheckedUpdateWithoutFriendshipRequestsReceivedInput>;
};
export type UserCreateWithoutChannelsInput = {
    id?: string;
    email: string;
    passwordHash: string;
    displayName: string;
    createdAt?: Date | string;
    updatedAt?: Date | string;
    messages?: Prisma.MessageCreateNestedManyWithoutUserInput;
    friendshipRequestsSent?: Prisma.FriendShipRequestCreateNestedManyWithoutRequesterInput;
    friendshipRequestsReceived?: Prisma.FriendShipRequestCreateNestedManyWithoutAddresseeInput;
    channelMembers?: Prisma.ChannelMemberCreateNestedManyWithoutUserInput;
};
export type UserUncheckedCreateWithoutChannelsInput = {
    id?: string;
    email: string;
    passwordHash: string;
    displayName: string;
    createdAt?: Date | string;
    updatedAt?: Date | string;
    messages?: Prisma.MessageUncheckedCreateNestedManyWithoutUserInput;
    friendshipRequestsSent?: Prisma.FriendShipRequestUncheckedCreateNestedManyWithoutRequesterInput;
    friendshipRequestsReceived?: Prisma.FriendShipRequestUncheckedCreateNestedManyWithoutAddresseeInput;
    channelMembers?: Prisma.ChannelMemberUncheckedCreateNestedManyWithoutUserInput;
};
export type UserCreateOrConnectWithoutChannelsInput = {
    where: Prisma.UserWhereUniqueInput;
    create: Prisma.XOR<Prisma.UserCreateWithoutChannelsInput, Prisma.UserUncheckedCreateWithoutChannelsInput>;
};
export type UserUpsertWithoutChannelsInput = {
    update: Prisma.XOR<Prisma.UserUpdateWithoutChannelsInput, Prisma.UserUncheckedUpdateWithoutChannelsInput>;
    create: Prisma.XOR<Prisma.UserCreateWithoutChannelsInput, Prisma.UserUncheckedCreateWithoutChannelsInput>;
    where?: Prisma.UserWhereInput;
};
export type UserUpdateToOneWithWhereWithoutChannelsInput = {
    where?: Prisma.UserWhereInput;
    data: Prisma.XOR<Prisma.UserUpdateWithoutChannelsInput, Prisma.UserUncheckedUpdateWithoutChannelsInput>;
};
export type UserUpdateWithoutChannelsInput = {
    id?: Prisma.StringFieldUpdateOperationsInput | string;
    email?: Prisma.StringFieldUpdateOperationsInput | string;
    passwordHash?: Prisma.StringFieldUpdateOperationsInput | string;
    displayName?: Prisma.StringFieldUpdateOperationsInput | string;
    createdAt?: Prisma.DateTimeFieldUpdateOperationsInput | Date | string;
    updatedAt?: Prisma.DateTimeFieldUpdateOperationsInput | Date | string;
    messages?: Prisma.MessageUpdateManyWithoutUserNestedInput;
    friendshipRequestsSent?: Prisma.FriendShipRequestUpdateManyWithoutRequesterNestedInput;
    friendshipRequestsReceived?: Prisma.FriendShipRequestUpdateManyWithoutAddresseeNestedInput;
    channelMembers?: Prisma.ChannelMemberUpdateManyWithoutUserNestedInput;
};
export type UserUncheckedUpdateWithoutChannelsInput = {
    id?: Prisma.StringFieldUpdateOperationsInput | string;
    email?: Prisma.StringFieldUpdateOperationsInput | string;
    passwordHash?: Prisma.StringFieldUpdateOperationsInput | string;
    displayName?: Prisma.StringFieldUpdateOperationsInput | string;
    createdAt?: Prisma.DateTimeFieldUpdateOperationsInput | Date | string;
    updatedAt?: Prisma.DateTimeFieldUpdateOperationsInput | Date | string;
    messages?: Prisma.MessageUncheckedUpdateManyWithoutUserNestedInput;
    friendshipRequestsSent?: Prisma.FriendShipRequestUncheckedUpdateManyWithoutRequesterNestedInput;
    friendshipRequestsReceived?: Prisma.FriendShipRequestUncheckedUpdateManyWithoutAddresseeNestedInput;
    channelMembers?: Prisma.ChannelMemberUncheckedUpdateManyWithoutUserNestedInput;
};
export type UserCreateWithoutMessagesInput = {
    id?: string;
    email: string;
    passwordHash: string;
    displayName: string;
    createdAt?: Date | string;
    updatedAt?: Date | string;
    channels?: Prisma.ChannelCreateNestedManyWithoutCreatedByInput;
    friendshipRequestsSent?: Prisma.FriendShipRequestCreateNestedManyWithoutRequesterInput;
    friendshipRequestsReceived?: Prisma.FriendShipRequestCreateNestedManyWithoutAddresseeInput;
    channelMembers?: Prisma.ChannelMemberCreateNestedManyWithoutUserInput;
};
export type UserUncheckedCreateWithoutMessagesInput = {
    id?: string;
    email: string;
    passwordHash: string;
    displayName: string;
    createdAt?: Date | string;
    updatedAt?: Date | string;
    channels?: Prisma.ChannelUncheckedCreateNestedManyWithoutCreatedByInput;
    friendshipRequestsSent?: Prisma.FriendShipRequestUncheckedCreateNestedManyWithoutRequesterInput;
    friendshipRequestsReceived?: Prisma.FriendShipRequestUncheckedCreateNestedManyWithoutAddresseeInput;
    channelMembers?: Prisma.ChannelMemberUncheckedCreateNestedManyWithoutUserInput;
};
export type UserCreateOrConnectWithoutMessagesInput = {
    where: Prisma.UserWhereUniqueInput;
    create: Prisma.XOR<Prisma.UserCreateWithoutMessagesInput, Prisma.UserUncheckedCreateWithoutMessagesInput>;
};
export type UserUpsertWithoutMessagesInput = {
    update: Prisma.XOR<Prisma.UserUpdateWithoutMessagesInput, Prisma.UserUncheckedUpdateWithoutMessagesInput>;
    create: Prisma.XOR<Prisma.UserCreateWithoutMessagesInput, Prisma.UserUncheckedCreateWithoutMessagesInput>;
    where?: Prisma.UserWhereInput;
};
export type UserUpdateToOneWithWhereWithoutMessagesInput = {
    where?: Prisma.UserWhereInput;
    data: Prisma.XOR<Prisma.UserUpdateWithoutMessagesInput, Prisma.UserUncheckedUpdateWithoutMessagesInput>;
};
export type UserUpdateWithoutMessagesInput = {
    id?: Prisma.StringFieldUpdateOperationsInput | string;
    email?: Prisma.StringFieldUpdateOperationsInput | string;
    passwordHash?: Prisma.StringFieldUpdateOperationsInput | string;
    displayName?: Prisma.StringFieldUpdateOperationsInput | string;
    createdAt?: Prisma.DateTimeFieldUpdateOperationsInput | Date | string;
    updatedAt?: Prisma.DateTimeFieldUpdateOperationsInput | Date | string;
    channels?: Prisma.ChannelUpdateManyWithoutCreatedByNestedInput;
    friendshipRequestsSent?: Prisma.FriendShipRequestUpdateManyWithoutRequesterNestedInput;
    friendshipRequestsReceived?: Prisma.FriendShipRequestUpdateManyWithoutAddresseeNestedInput;
    channelMembers?: Prisma.ChannelMemberUpdateManyWithoutUserNestedInput;
};
export type UserUncheckedUpdateWithoutMessagesInput = {
    id?: Prisma.StringFieldUpdateOperationsInput | string;
    email?: Prisma.StringFieldUpdateOperationsInput | string;
    passwordHash?: Prisma.StringFieldUpdateOperationsInput | string;
    displayName?: Prisma.StringFieldUpdateOperationsInput | string;
    createdAt?: Prisma.DateTimeFieldUpdateOperationsInput | Date | string;
    updatedAt?: Prisma.DateTimeFieldUpdateOperationsInput | Date | string;
    channels?: Prisma.ChannelUncheckedUpdateManyWithoutCreatedByNestedInput;
    friendshipRequestsSent?: Prisma.FriendShipRequestUncheckedUpdateManyWithoutRequesterNestedInput;
    friendshipRequestsReceived?: Prisma.FriendShipRequestUncheckedUpdateManyWithoutAddresseeNestedInput;
    channelMembers?: Prisma.ChannelMemberUncheckedUpdateManyWithoutUserNestedInput;
};
export type UserCreateWithoutChannelMembersInput = {
    id?: string;
    email: string;
    passwordHash: string;
    displayName: string;
    createdAt?: Date | string;
    updatedAt?: Date | string;
    messages?: Prisma.MessageCreateNestedManyWithoutUserInput;
    channels?: Prisma.ChannelCreateNestedManyWithoutCreatedByInput;
    friendshipRequestsSent?: Prisma.FriendShipRequestCreateNestedManyWithoutRequesterInput;
    friendshipRequestsReceived?: Prisma.FriendShipRequestCreateNestedManyWithoutAddresseeInput;
};
export type UserUncheckedCreateWithoutChannelMembersInput = {
    id?: string;
    email: string;
    passwordHash: string;
    displayName: string;
    createdAt?: Date | string;
    updatedAt?: Date | string;
    messages?: Prisma.MessageUncheckedCreateNestedManyWithoutUserInput;
    channels?: Prisma.ChannelUncheckedCreateNestedManyWithoutCreatedByInput;
    friendshipRequestsSent?: Prisma.FriendShipRequestUncheckedCreateNestedManyWithoutRequesterInput;
    friendshipRequestsReceived?: Prisma.FriendShipRequestUncheckedCreateNestedManyWithoutAddresseeInput;
};
export type UserCreateOrConnectWithoutChannelMembersInput = {
    where: Prisma.UserWhereUniqueInput;
    create: Prisma.XOR<Prisma.UserCreateWithoutChannelMembersInput, Prisma.UserUncheckedCreateWithoutChannelMembersInput>;
};
export type UserUpsertWithoutChannelMembersInput = {
    update: Prisma.XOR<Prisma.UserUpdateWithoutChannelMembersInput, Prisma.UserUncheckedUpdateWithoutChannelMembersInput>;
    create: Prisma.XOR<Prisma.UserCreateWithoutChannelMembersInput, Prisma.UserUncheckedCreateWithoutChannelMembersInput>;
    where?: Prisma.UserWhereInput;
};
export type UserUpdateToOneWithWhereWithoutChannelMembersInput = {
    where?: Prisma.UserWhereInput;
    data: Prisma.XOR<Prisma.UserUpdateWithoutChannelMembersInput, Prisma.UserUncheckedUpdateWithoutChannelMembersInput>;
};
export type UserUpdateWithoutChannelMembersInput = {
    id?: Prisma.StringFieldUpdateOperationsInput | string;
    email?: Prisma.StringFieldUpdateOperationsInput | string;
    passwordHash?: Prisma.StringFieldUpdateOperationsInput | string;
    displayName?: Prisma.StringFieldUpdateOperationsInput | string;
    createdAt?: Prisma.DateTimeFieldUpdateOperationsInput | Date | string;
    updatedAt?: Prisma.DateTimeFieldUpdateOperationsInput | Date | string;
    messages?: Prisma.MessageUpdateManyWithoutUserNestedInput;
    channels?: Prisma.ChannelUpdateManyWithoutCreatedByNestedInput;
    friendshipRequestsSent?: Prisma.FriendShipRequestUpdateManyWithoutRequesterNestedInput;
    friendshipRequestsReceived?: Prisma.FriendShipRequestUpdateManyWithoutAddresseeNestedInput;
};
export type UserUncheckedUpdateWithoutChannelMembersInput = {
    id?: Prisma.StringFieldUpdateOperationsInput | string;
    email?: Prisma.StringFieldUpdateOperationsInput | string;
    passwordHash?: Prisma.StringFieldUpdateOperationsInput | string;
    displayName?: Prisma.StringFieldUpdateOperationsInput | string;
    createdAt?: Prisma.DateTimeFieldUpdateOperationsInput | Date | string;
    updatedAt?: Prisma.DateTimeFieldUpdateOperationsInput | Date | string;
    messages?: Prisma.MessageUncheckedUpdateManyWithoutUserNestedInput;
    channels?: Prisma.ChannelUncheckedUpdateManyWithoutCreatedByNestedInput;
    friendshipRequestsSent?: Prisma.FriendShipRequestUncheckedUpdateManyWithoutRequesterNestedInput;
    friendshipRequestsReceived?: Prisma.FriendShipRequestUncheckedUpdateManyWithoutAddresseeNestedInput;
};
export type UserCreateWithoutFriendshipRequestsSentInput = {
    id?: string;
    email: string;
    passwordHash: string;
    displayName: string;
    createdAt?: Date | string;
    updatedAt?: Date | string;
    messages?: Prisma.MessageCreateNestedManyWithoutUserInput;
    channels?: Prisma.ChannelCreateNestedManyWithoutCreatedByInput;
    friendshipRequestsReceived?: Prisma.FriendShipRequestCreateNestedManyWithoutAddresseeInput;
    channelMembers?: Prisma.ChannelMemberCreateNestedManyWithoutUserInput;
};
export type UserUncheckedCreateWithoutFriendshipRequestsSentInput = {
    id?: string;
    email: string;
    passwordHash: string;
    displayName: string;
    createdAt?: Date | string;
    updatedAt?: Date | string;
    messages?: Prisma.MessageUncheckedCreateNestedManyWithoutUserInput;
    channels?: Prisma.ChannelUncheckedCreateNestedManyWithoutCreatedByInput;
    friendshipRequestsReceived?: Prisma.FriendShipRequestUncheckedCreateNestedManyWithoutAddresseeInput;
    channelMembers?: Prisma.ChannelMemberUncheckedCreateNestedManyWithoutUserInput;
};
export type UserCreateOrConnectWithoutFriendshipRequestsSentInput = {
    where: Prisma.UserWhereUniqueInput;
    create: Prisma.XOR<Prisma.UserCreateWithoutFriendshipRequestsSentInput, Prisma.UserUncheckedCreateWithoutFriendshipRequestsSentInput>;
};
export type UserCreateWithoutFriendshipRequestsReceivedInput = {
    id?: string;
    email: string;
    passwordHash: string;
    displayName: string;
    createdAt?: Date | string;
    updatedAt?: Date | string;
    messages?: Prisma.MessageCreateNestedManyWithoutUserInput;
    channels?: Prisma.ChannelCreateNestedManyWithoutCreatedByInput;
    friendshipRequestsSent?: Prisma.FriendShipRequestCreateNestedManyWithoutRequesterInput;
    channelMembers?: Prisma.ChannelMemberCreateNestedManyWithoutUserInput;
};
export type UserUncheckedCreateWithoutFriendshipRequestsReceivedInput = {
    id?: string;
    email: string;
    passwordHash: string;
    displayName: string;
    createdAt?: Date | string;
    updatedAt?: Date | string;
    messages?: Prisma.MessageUncheckedCreateNestedManyWithoutUserInput;
    channels?: Prisma.ChannelUncheckedCreateNestedManyWithoutCreatedByInput;
    friendshipRequestsSent?: Prisma.FriendShipRequestUncheckedCreateNestedManyWithoutRequesterInput;
    channelMembers?: Prisma.ChannelMemberUncheckedCreateNestedManyWithoutUserInput;
};
export type UserCreateOrConnectWithoutFriendshipRequestsReceivedInput = {
    where: Prisma.UserWhereUniqueInput;
    create: Prisma.XOR<Prisma.UserCreateWithoutFriendshipRequestsReceivedInput, Prisma.UserUncheckedCreateWithoutFriendshipRequestsReceivedInput>;
};
export type UserUpsertWithoutFriendshipRequestsSentInput = {
    update: Prisma.XOR<Prisma.UserUpdateWithoutFriendshipRequestsSentInput, Prisma.UserUncheckedUpdateWithoutFriendshipRequestsSentInput>;
    create: Prisma.XOR<Prisma.UserCreateWithoutFriendshipRequestsSentInput, Prisma.UserUncheckedCreateWithoutFriendshipRequestsSentInput>;
    where?: Prisma.UserWhereInput;
};
export type UserUpdateToOneWithWhereWithoutFriendshipRequestsSentInput = {
    where?: Prisma.UserWhereInput;
    data: Prisma.XOR<Prisma.UserUpdateWithoutFriendshipRequestsSentInput, Prisma.UserUncheckedUpdateWithoutFriendshipRequestsSentInput>;
};
export type UserUpdateWithoutFriendshipRequestsSentInput = {
    id?: Prisma.StringFieldUpdateOperationsInput | string;
    email?: Prisma.StringFieldUpdateOperationsInput | string;
    passwordHash?: Prisma.StringFieldUpdateOperationsInput | string;
    displayName?: Prisma.StringFieldUpdateOperationsInput | string;
    createdAt?: Prisma.DateTimeFieldUpdateOperationsInput | Date | string;
    updatedAt?: Prisma.DateTimeFieldUpdateOperationsInput | Date | string;
    messages?: Prisma.MessageUpdateManyWithoutUserNestedInput;
    channels?: Prisma.ChannelUpdateManyWithoutCreatedByNestedInput;
    friendshipRequestsReceived?: Prisma.FriendShipRequestUpdateManyWithoutAddresseeNestedInput;
    channelMembers?: Prisma.ChannelMemberUpdateManyWithoutUserNestedInput;
};
export type UserUncheckedUpdateWithoutFriendshipRequestsSentInput = {
    id?: Prisma.StringFieldUpdateOperationsInput | string;
    email?: Prisma.StringFieldUpdateOperationsInput | string;
    passwordHash?: Prisma.StringFieldUpdateOperationsInput | string;
    displayName?: Prisma.StringFieldUpdateOperationsInput | string;
    createdAt?: Prisma.DateTimeFieldUpdateOperationsInput | Date | string;
    updatedAt?: Prisma.DateTimeFieldUpdateOperationsInput | Date | string;
    messages?: Prisma.MessageUncheckedUpdateManyWithoutUserNestedInput;
    channels?: Prisma.ChannelUncheckedUpdateManyWithoutCreatedByNestedInput;
    friendshipRequestsReceived?: Prisma.FriendShipRequestUncheckedUpdateManyWithoutAddresseeNestedInput;
    channelMembers?: Prisma.ChannelMemberUncheckedUpdateManyWithoutUserNestedInput;
};
export type UserUpsertWithoutFriendshipRequestsReceivedInput = {
    update: Prisma.XOR<Prisma.UserUpdateWithoutFriendshipRequestsReceivedInput, Prisma.UserUncheckedUpdateWithoutFriendshipRequestsReceivedInput>;
    create: Prisma.XOR<Prisma.UserCreateWithoutFriendshipRequestsReceivedInput, Prisma.UserUncheckedCreateWithoutFriendshipRequestsReceivedInput>;
    where?: Prisma.UserWhereInput;
};
export type UserUpdateToOneWithWhereWithoutFriendshipRequestsReceivedInput = {
    where?: Prisma.UserWhereInput;
    data: Prisma.XOR<Prisma.UserUpdateWithoutFriendshipRequestsReceivedInput, Prisma.UserUncheckedUpdateWithoutFriendshipRequestsReceivedInput>;
};
export type UserUpdateWithoutFriendshipRequestsReceivedInput = {
    id?: Prisma.StringFieldUpdateOperationsInput | string;
    email?: Prisma.StringFieldUpdateOperationsInput | string;
    passwordHash?: Prisma.StringFieldUpdateOperationsInput | string;
    displayName?: Prisma.StringFieldUpdateOperationsInput | string;
    createdAt?: Prisma.DateTimeFieldUpdateOperationsInput | Date | string;
    updatedAt?: Prisma.DateTimeFieldUpdateOperationsInput | Date | string;
    messages?: Prisma.MessageUpdateManyWithoutUserNestedInput;
    channels?: Prisma.ChannelUpdateManyWithoutCreatedByNestedInput;
    friendshipRequestsSent?: Prisma.FriendShipRequestUpdateManyWithoutRequesterNestedInput;
    channelMembers?: Prisma.ChannelMemberUpdateManyWithoutUserNestedInput;
};
export type UserUncheckedUpdateWithoutFriendshipRequestsReceivedInput = {
    id?: Prisma.StringFieldUpdateOperationsInput | string;
    email?: Prisma.StringFieldUpdateOperationsInput | string;
    passwordHash?: Prisma.StringFieldUpdateOperationsInput | string;
    displayName?: Prisma.StringFieldUpdateOperationsInput | string;
    createdAt?: Prisma.DateTimeFieldUpdateOperationsInput | Date | string;
    updatedAt?: Prisma.DateTimeFieldUpdateOperationsInput | Date | string;
    messages?: Prisma.MessageUncheckedUpdateManyWithoutUserNestedInput;
    channels?: Prisma.ChannelUncheckedUpdateManyWithoutCreatedByNestedInput;
    friendshipRequestsSent?: Prisma.FriendShipRequestUncheckedUpdateManyWithoutRequesterNestedInput;
    channelMembers?: Prisma.ChannelMemberUncheckedUpdateManyWithoutUserNestedInput;
};
export type UserCountOutputType = {
    messages: number;
    channels: number;
    friendshipRequestsSent: number;
    friendshipRequestsReceived: number;
    channelMembers: number;
};
export type UserCountOutputTypeSelect<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    messages?: boolean | UserCountOutputTypeCountMessagesArgs;
    channels?: boolean | UserCountOutputTypeCountChannelsArgs;
    friendshipRequestsSent?: boolean | UserCountOutputTypeCountFriendshipRequestsSentArgs;
    friendshipRequestsReceived?: boolean | UserCountOutputTypeCountFriendshipRequestsReceivedArgs;
    channelMembers?: boolean | UserCountOutputTypeCountChannelMembersArgs;
};
export type UserCountOutputTypeDefaultArgs<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    select?: Prisma.UserCountOutputTypeSelect<ExtArgs> | null;
};
export type UserCountOutputTypeCountMessagesArgs<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    where?: Prisma.MessageWhereInput;
};
export type UserCountOutputTypeCountChannelsArgs<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    where?: Prisma.ChannelWhereInput;
};
export type UserCountOutputTypeCountFriendshipRequestsSentArgs<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    where?: Prisma.FriendShipRequestWhereInput;
};
export type UserCountOutputTypeCountFriendshipRequestsReceivedArgs<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    where?: Prisma.FriendShipRequestWhereInput;
};
export type UserCountOutputTypeCountChannelMembersArgs<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    where?: Prisma.ChannelMemberWhereInput;
};
export type UserSelect<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = runtime.Types.Extensions.GetSelect<{
    id?: boolean;
    email?: boolean;
    passwordHash?: boolean;
    displayName?: boolean;
    createdAt?: boolean;
    updatedAt?: boolean;
    messages?: boolean | Prisma.User$messagesArgs<ExtArgs>;
    channels?: boolean | Prisma.User$channelsArgs<ExtArgs>;
    friendshipRequestsSent?: boolean | Prisma.User$friendshipRequestsSentArgs<ExtArgs>;
    friendshipRequestsReceived?: boolean | Prisma.User$friendshipRequestsReceivedArgs<ExtArgs>;
    channelMembers?: boolean | Prisma.User$channelMembersArgs<ExtArgs>;
    _count?: boolean | Prisma.UserCountOutputTypeDefaultArgs<ExtArgs>;
}, ExtArgs["result"]["user"]>;
export type UserSelectCreateManyAndReturn<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = runtime.Types.Extensions.GetSelect<{
    id?: boolean;
    email?: boolean;
    passwordHash?: boolean;
    displayName?: boolean;
    createdAt?: boolean;
    updatedAt?: boolean;
}, ExtArgs["result"]["user"]>;
export type UserSelectUpdateManyAndReturn<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = runtime.Types.Extensions.GetSelect<{
    id?: boolean;
    email?: boolean;
    passwordHash?: boolean;
    displayName?: boolean;
    createdAt?: boolean;
    updatedAt?: boolean;
}, ExtArgs["result"]["user"]>;
export type UserSelectScalar = {
    id?: boolean;
    email?: boolean;
    passwordHash?: boolean;
    displayName?: boolean;
    createdAt?: boolean;
    updatedAt?: boolean;
};
export type UserOmit<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = runtime.Types.Extensions.GetOmit<"id" | "email" | "passwordHash" | "displayName" | "createdAt" | "updatedAt", ExtArgs["result"]["user"]>;
export type UserInclude<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    messages?: boolean | Prisma.User$messagesArgs<ExtArgs>;
    channels?: boolean | Prisma.User$channelsArgs<ExtArgs>;
    friendshipRequestsSent?: boolean | Prisma.User$friendshipRequestsSentArgs<ExtArgs>;
    friendshipRequestsReceived?: boolean | Prisma.User$friendshipRequestsReceivedArgs<ExtArgs>;
    channelMembers?: boolean | Prisma.User$channelMembersArgs<ExtArgs>;
    _count?: boolean | Prisma.UserCountOutputTypeDefaultArgs<ExtArgs>;
};
export type UserIncludeCreateManyAndReturn<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {};
export type UserIncludeUpdateManyAndReturn<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {};
export type $UserPayload<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    name: "User";
    objects: {
        messages: Prisma.$MessagePayload<ExtArgs>[];
        channels: Prisma.$ChannelPayload<ExtArgs>[];
        friendshipRequestsSent: Prisma.$FriendShipRequestPayload<ExtArgs>[];
        friendshipRequestsReceived: Prisma.$FriendShipRequestPayload<ExtArgs>[];
        channelMembers: Prisma.$ChannelMemberPayload<ExtArgs>[];
    };
    scalars: runtime.Types.Extensions.GetPayloadResult<{
        id: string;
        email: string;
        passwordHash: string;
        displayName: string;
        createdAt: Date;
        updatedAt: Date;
    }, ExtArgs["result"]["user"]>;
    composites: {};
};
export type UserGetPayload<S extends boolean | null | undefined | UserDefaultArgs> = runtime.Types.Result.GetResult<Prisma.$UserPayload, S>;
export type UserCountArgs<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = Omit<UserFindManyArgs, 'select' | 'include' | 'distinct' | 'omit'> & {
    select?: UserCountAggregateInputType | true;
};
export interface UserDelegate<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs, GlobalOmitOptions = {}> {
    [K: symbol]: {
        types: Prisma.TypeMap<ExtArgs>['model']['User'];
        meta: {
            name: 'User';
        };
    };
    findUnique<T extends UserFindUniqueArgs>(args: Prisma.SelectSubset<T, UserFindUniqueArgs<ExtArgs>>): Prisma.Prisma__UserClient<runtime.Types.Result.GetResult<Prisma.$UserPayload<ExtArgs>, T, "findUnique", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>;
    findUniqueOrThrow<T extends UserFindUniqueOrThrowArgs>(args: Prisma.SelectSubset<T, UserFindUniqueOrThrowArgs<ExtArgs>>): Prisma.Prisma__UserClient<runtime.Types.Result.GetResult<Prisma.$UserPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>;
    findFirst<T extends UserFindFirstArgs>(args?: Prisma.SelectSubset<T, UserFindFirstArgs<ExtArgs>>): Prisma.Prisma__UserClient<runtime.Types.Result.GetResult<Prisma.$UserPayload<ExtArgs>, T, "findFirst", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>;
    findFirstOrThrow<T extends UserFindFirstOrThrowArgs>(args?: Prisma.SelectSubset<T, UserFindFirstOrThrowArgs<ExtArgs>>): Prisma.Prisma__UserClient<runtime.Types.Result.GetResult<Prisma.$UserPayload<ExtArgs>, T, "findFirstOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>;
    findMany<T extends UserFindManyArgs>(args?: Prisma.SelectSubset<T, UserFindManyArgs<ExtArgs>>): Prisma.PrismaPromise<runtime.Types.Result.GetResult<Prisma.$UserPayload<ExtArgs>, T, "findMany", GlobalOmitOptions>>;
    create<T extends UserCreateArgs>(args: Prisma.SelectSubset<T, UserCreateArgs<ExtArgs>>): Prisma.Prisma__UserClient<runtime.Types.Result.GetResult<Prisma.$UserPayload<ExtArgs>, T, "create", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>;
    createMany<T extends UserCreateManyArgs>(args?: Prisma.SelectSubset<T, UserCreateManyArgs<ExtArgs>>): Prisma.PrismaPromise<Prisma.BatchPayload>;
    createManyAndReturn<T extends UserCreateManyAndReturnArgs>(args?: Prisma.SelectSubset<T, UserCreateManyAndReturnArgs<ExtArgs>>): Prisma.PrismaPromise<runtime.Types.Result.GetResult<Prisma.$UserPayload<ExtArgs>, T, "createManyAndReturn", GlobalOmitOptions>>;
    delete<T extends UserDeleteArgs>(args: Prisma.SelectSubset<T, UserDeleteArgs<ExtArgs>>): Prisma.Prisma__UserClient<runtime.Types.Result.GetResult<Prisma.$UserPayload<ExtArgs>, T, "delete", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>;
    update<T extends UserUpdateArgs>(args: Prisma.SelectSubset<T, UserUpdateArgs<ExtArgs>>): Prisma.Prisma__UserClient<runtime.Types.Result.GetResult<Prisma.$UserPayload<ExtArgs>, T, "update", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>;
    deleteMany<T extends UserDeleteManyArgs>(args?: Prisma.SelectSubset<T, UserDeleteManyArgs<ExtArgs>>): Prisma.PrismaPromise<Prisma.BatchPayload>;
    updateMany<T extends UserUpdateManyArgs>(args: Prisma.SelectSubset<T, UserUpdateManyArgs<ExtArgs>>): Prisma.PrismaPromise<Prisma.BatchPayload>;
    updateManyAndReturn<T extends UserUpdateManyAndReturnArgs>(args: Prisma.SelectSubset<T, UserUpdateManyAndReturnArgs<ExtArgs>>): Prisma.PrismaPromise<runtime.Types.Result.GetResult<Prisma.$UserPayload<ExtArgs>, T, "updateManyAndReturn", GlobalOmitOptions>>;
    upsert<T extends UserUpsertArgs>(args: Prisma.SelectSubset<T, UserUpsertArgs<ExtArgs>>): Prisma.Prisma__UserClient<runtime.Types.Result.GetResult<Prisma.$UserPayload<ExtArgs>, T, "upsert", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>;
    count<T extends UserCountArgs>(args?: Prisma.Subset<T, UserCountArgs>): Prisma.PrismaPromise<T extends runtime.Types.Utils.Record<'select', any> ? T['select'] extends true ? number : Prisma.GetScalarType<T['select'], UserCountAggregateOutputType> : number>;
    aggregate<T extends UserAggregateArgs>(args: Prisma.Subset<T, UserAggregateArgs>): Prisma.PrismaPromise<GetUserAggregateType<T>>;
    groupBy<T extends UserGroupByArgs, HasSelectOrTake extends Prisma.Or<Prisma.Extends<'skip', Prisma.Keys<T>>, Prisma.Extends<'take', Prisma.Keys<T>>>, OrderByArg extends Prisma.True extends HasSelectOrTake ? {
        orderBy: UserGroupByArgs['orderBy'];
    } : {
        orderBy?: UserGroupByArgs['orderBy'];
    }, OrderFields extends Prisma.ExcludeUnderscoreKeys<Prisma.Keys<Prisma.MaybeTupleToUnion<T['orderBy']>>>, ByFields extends Prisma.MaybeTupleToUnion<T['by']>, ByValid extends Prisma.Has<ByFields, OrderFields>, HavingFields extends Prisma.GetHavingFields<T['having']>, HavingValid extends Prisma.Has<ByFields, HavingFields>, ByEmpty extends T['by'] extends never[] ? Prisma.True : Prisma.False, InputErrors extends ByEmpty extends Prisma.True ? `Error: "by" must not be empty.` : HavingValid extends Prisma.False ? {
        [P in HavingFields]: P extends ByFields ? never : P extends string ? `Error: Field "${P}" used in "having" needs to be provided in "by".` : [
            Error,
            'Field ',
            P,
            ` in "having" needs to be provided in "by"`
        ];
    }[HavingFields] : 'take' extends Prisma.Keys<T> ? 'orderBy' extends Prisma.Keys<T> ? ByValid extends Prisma.True ? {} : {
        [P in OrderFields]: P extends ByFields ? never : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`;
    }[OrderFields] : 'Error: If you provide "take", you also need to provide "orderBy"' : 'skip' extends Prisma.Keys<T> ? 'orderBy' extends Prisma.Keys<T> ? ByValid extends Prisma.True ? {} : {
        [P in OrderFields]: P extends ByFields ? never : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`;
    }[OrderFields] : 'Error: If you provide "skip", you also need to provide "orderBy"' : ByValid extends Prisma.True ? {} : {
        [P in OrderFields]: P extends ByFields ? never : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`;
    }[OrderFields]>(args: Prisma.SubsetIntersection<T, UserGroupByArgs, OrderByArg> & InputErrors): {} extends InputErrors ? GetUserGroupByPayload<T> : Prisma.PrismaPromise<InputErrors>;
    readonly fields: UserFieldRefs;
}
export interface Prisma__UserClient<T, Null = never, ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs, GlobalOmitOptions = {}> extends Prisma.PrismaPromise<T> {
    readonly [Symbol.toStringTag]: "PrismaPromise";
    messages<T extends Prisma.User$messagesArgs<ExtArgs> = {}>(args?: Prisma.Subset<T, Prisma.User$messagesArgs<ExtArgs>>): Prisma.PrismaPromise<runtime.Types.Result.GetResult<Prisma.$MessagePayload<ExtArgs>, T, "findMany", GlobalOmitOptions> | Null>;
    channels<T extends Prisma.User$channelsArgs<ExtArgs> = {}>(args?: Prisma.Subset<T, Prisma.User$channelsArgs<ExtArgs>>): Prisma.PrismaPromise<runtime.Types.Result.GetResult<Prisma.$ChannelPayload<ExtArgs>, T, "findMany", GlobalOmitOptions> | Null>;
    friendshipRequestsSent<T extends Prisma.User$friendshipRequestsSentArgs<ExtArgs> = {}>(args?: Prisma.Subset<T, Prisma.User$friendshipRequestsSentArgs<ExtArgs>>): Prisma.PrismaPromise<runtime.Types.Result.GetResult<Prisma.$FriendShipRequestPayload<ExtArgs>, T, "findMany", GlobalOmitOptions> | Null>;
    friendshipRequestsReceived<T extends Prisma.User$friendshipRequestsReceivedArgs<ExtArgs> = {}>(args?: Prisma.Subset<T, Prisma.User$friendshipRequestsReceivedArgs<ExtArgs>>): Prisma.PrismaPromise<runtime.Types.Result.GetResult<Prisma.$FriendShipRequestPayload<ExtArgs>, T, "findMany", GlobalOmitOptions> | Null>;
    channelMembers<T extends Prisma.User$channelMembersArgs<ExtArgs> = {}>(args?: Prisma.Subset<T, Prisma.User$channelMembersArgs<ExtArgs>>): Prisma.PrismaPromise<runtime.Types.Result.GetResult<Prisma.$ChannelMemberPayload<ExtArgs>, T, "findMany", GlobalOmitOptions> | Null>;
    then<TResult1 = T, TResult2 = never>(onfulfilled?: ((value: T) => TResult1 | PromiseLike<TResult1>) | undefined | null, onrejected?: ((reason: any) => TResult2 | PromiseLike<TResult2>) | undefined | null): runtime.Types.Utils.JsPromise<TResult1 | TResult2>;
    catch<TResult = never>(onrejected?: ((reason: any) => TResult | PromiseLike<TResult>) | undefined | null): runtime.Types.Utils.JsPromise<T | TResult>;
    finally(onfinally?: (() => void) | undefined | null): runtime.Types.Utils.JsPromise<T>;
}
export interface UserFieldRefs {
    readonly id: Prisma.FieldRef<"User", 'String'>;
    readonly email: Prisma.FieldRef<"User", 'String'>;
    readonly passwordHash: Prisma.FieldRef<"User", 'String'>;
    readonly displayName: Prisma.FieldRef<"User", 'String'>;
    readonly createdAt: Prisma.FieldRef<"User", 'DateTime'>;
    readonly updatedAt: Prisma.FieldRef<"User", 'DateTime'>;
}
export type UserFindUniqueArgs<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    select?: Prisma.UserSelect<ExtArgs> | null;
    omit?: Prisma.UserOmit<ExtArgs> | null;
    include?: Prisma.UserInclude<ExtArgs> | null;
    where: Prisma.UserWhereUniqueInput;
};
export type UserFindUniqueOrThrowArgs<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    select?: Prisma.UserSelect<ExtArgs> | null;
    omit?: Prisma.UserOmit<ExtArgs> | null;
    include?: Prisma.UserInclude<ExtArgs> | null;
    where: Prisma.UserWhereUniqueInput;
};
export type UserFindFirstArgs<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    select?: Prisma.UserSelect<ExtArgs> | null;
    omit?: Prisma.UserOmit<ExtArgs> | null;
    include?: Prisma.UserInclude<ExtArgs> | null;
    where?: Prisma.UserWhereInput;
    orderBy?: Prisma.UserOrderByWithRelationInput | Prisma.UserOrderByWithRelationInput[];
    cursor?: Prisma.UserWhereUniqueInput;
    take?: number;
    skip?: number;
    distinct?: Prisma.UserScalarFieldEnum | Prisma.UserScalarFieldEnum[];
};
export type UserFindFirstOrThrowArgs<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    select?: Prisma.UserSelect<ExtArgs> | null;
    omit?: Prisma.UserOmit<ExtArgs> | null;
    include?: Prisma.UserInclude<ExtArgs> | null;
    where?: Prisma.UserWhereInput;
    orderBy?: Prisma.UserOrderByWithRelationInput | Prisma.UserOrderByWithRelationInput[];
    cursor?: Prisma.UserWhereUniqueInput;
    take?: number;
    skip?: number;
    distinct?: Prisma.UserScalarFieldEnum | Prisma.UserScalarFieldEnum[];
};
export type UserFindManyArgs<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    select?: Prisma.UserSelect<ExtArgs> | null;
    omit?: Prisma.UserOmit<ExtArgs> | null;
    include?: Prisma.UserInclude<ExtArgs> | null;
    where?: Prisma.UserWhereInput;
    orderBy?: Prisma.UserOrderByWithRelationInput | Prisma.UserOrderByWithRelationInput[];
    cursor?: Prisma.UserWhereUniqueInput;
    take?: number;
    skip?: number;
    distinct?: Prisma.UserScalarFieldEnum | Prisma.UserScalarFieldEnum[];
};
export type UserCreateArgs<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    select?: Prisma.UserSelect<ExtArgs> | null;
    omit?: Prisma.UserOmit<ExtArgs> | null;
    include?: Prisma.UserInclude<ExtArgs> | null;
    data: Prisma.XOR<Prisma.UserCreateInput, Prisma.UserUncheckedCreateInput>;
};
export type UserCreateManyArgs<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    data: Prisma.UserCreateManyInput | Prisma.UserCreateManyInput[];
    skipDuplicates?: boolean;
};
export type UserCreateManyAndReturnArgs<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    select?: Prisma.UserSelectCreateManyAndReturn<ExtArgs> | null;
    omit?: Prisma.UserOmit<ExtArgs> | null;
    data: Prisma.UserCreateManyInput | Prisma.UserCreateManyInput[];
    skipDuplicates?: boolean;
};
export type UserUpdateArgs<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    select?: Prisma.UserSelect<ExtArgs> | null;
    omit?: Prisma.UserOmit<ExtArgs> | null;
    include?: Prisma.UserInclude<ExtArgs> | null;
    data: Prisma.XOR<Prisma.UserUpdateInput, Prisma.UserUncheckedUpdateInput>;
    where: Prisma.UserWhereUniqueInput;
};
export type UserUpdateManyArgs<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    data: Prisma.XOR<Prisma.UserUpdateManyMutationInput, Prisma.UserUncheckedUpdateManyInput>;
    where?: Prisma.UserWhereInput;
    limit?: number;
};
export type UserUpdateManyAndReturnArgs<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    select?: Prisma.UserSelectUpdateManyAndReturn<ExtArgs> | null;
    omit?: Prisma.UserOmit<ExtArgs> | null;
    data: Prisma.XOR<Prisma.UserUpdateManyMutationInput, Prisma.UserUncheckedUpdateManyInput>;
    where?: Prisma.UserWhereInput;
    limit?: number;
};
export type UserUpsertArgs<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    select?: Prisma.UserSelect<ExtArgs> | null;
    omit?: Prisma.UserOmit<ExtArgs> | null;
    include?: Prisma.UserInclude<ExtArgs> | null;
    where: Prisma.UserWhereUniqueInput;
    create: Prisma.XOR<Prisma.UserCreateInput, Prisma.UserUncheckedCreateInput>;
    update: Prisma.XOR<Prisma.UserUpdateInput, Prisma.UserUncheckedUpdateInput>;
};
export type UserDeleteArgs<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    select?: Prisma.UserSelect<ExtArgs> | null;
    omit?: Prisma.UserOmit<ExtArgs> | null;
    include?: Prisma.UserInclude<ExtArgs> | null;
    where: Prisma.UserWhereUniqueInput;
};
export type UserDeleteManyArgs<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    where?: Prisma.UserWhereInput;
    limit?: number;
};
export type User$messagesArgs<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    select?: Prisma.MessageSelect<ExtArgs> | null;
    omit?: Prisma.MessageOmit<ExtArgs> | null;
    include?: Prisma.MessageInclude<ExtArgs> | null;
    where?: Prisma.MessageWhereInput;
    orderBy?: Prisma.MessageOrderByWithRelationInput | Prisma.MessageOrderByWithRelationInput[];
    cursor?: Prisma.MessageWhereUniqueInput;
    take?: number;
    skip?: number;
    distinct?: Prisma.MessageScalarFieldEnum | Prisma.MessageScalarFieldEnum[];
};
export type User$channelsArgs<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    select?: Prisma.ChannelSelect<ExtArgs> | null;
    omit?: Prisma.ChannelOmit<ExtArgs> | null;
    include?: Prisma.ChannelInclude<ExtArgs> | null;
    where?: Prisma.ChannelWhereInput;
    orderBy?: Prisma.ChannelOrderByWithRelationInput | Prisma.ChannelOrderByWithRelationInput[];
    cursor?: Prisma.ChannelWhereUniqueInput;
    take?: number;
    skip?: number;
    distinct?: Prisma.ChannelScalarFieldEnum | Prisma.ChannelScalarFieldEnum[];
};
export type User$friendshipRequestsSentArgs<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    select?: Prisma.FriendShipRequestSelect<ExtArgs> | null;
    omit?: Prisma.FriendShipRequestOmit<ExtArgs> | null;
    include?: Prisma.FriendShipRequestInclude<ExtArgs> | null;
    where?: Prisma.FriendShipRequestWhereInput;
    orderBy?: Prisma.FriendShipRequestOrderByWithRelationInput | Prisma.FriendShipRequestOrderByWithRelationInput[];
    cursor?: Prisma.FriendShipRequestWhereUniqueInput;
    take?: number;
    skip?: number;
    distinct?: Prisma.FriendShipRequestScalarFieldEnum | Prisma.FriendShipRequestScalarFieldEnum[];
};
export type User$friendshipRequestsReceivedArgs<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    select?: Prisma.FriendShipRequestSelect<ExtArgs> | null;
    omit?: Prisma.FriendShipRequestOmit<ExtArgs> | null;
    include?: Prisma.FriendShipRequestInclude<ExtArgs> | null;
    where?: Prisma.FriendShipRequestWhereInput;
    orderBy?: Prisma.FriendShipRequestOrderByWithRelationInput | Prisma.FriendShipRequestOrderByWithRelationInput[];
    cursor?: Prisma.FriendShipRequestWhereUniqueInput;
    take?: number;
    skip?: number;
    distinct?: Prisma.FriendShipRequestScalarFieldEnum | Prisma.FriendShipRequestScalarFieldEnum[];
};
export type User$channelMembersArgs<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    select?: Prisma.ChannelMemberSelect<ExtArgs> | null;
    omit?: Prisma.ChannelMemberOmit<ExtArgs> | null;
    include?: Prisma.ChannelMemberInclude<ExtArgs> | null;
    where?: Prisma.ChannelMemberWhereInput;
    orderBy?: Prisma.ChannelMemberOrderByWithRelationInput | Prisma.ChannelMemberOrderByWithRelationInput[];
    cursor?: Prisma.ChannelMemberWhereUniqueInput;
    take?: number;
    skip?: number;
    distinct?: Prisma.ChannelMemberScalarFieldEnum | Prisma.ChannelMemberScalarFieldEnum[];
};
export type UserDefaultArgs<ExtArgs extends runtime.Types.Extensions.InternalArgs = runtime.Types.Extensions.DefaultArgs> = {
    select?: Prisma.UserSelect<ExtArgs> | null;
    omit?: Prisma.UserOmit<ExtArgs> | null;
    include?: Prisma.UserInclude<ExtArgs> | null;
};
export {};
