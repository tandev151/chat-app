import * as Prisma from './internal/prismaNamespaceBrowser';
export { Prisma };
export * as $Enums from './enums';
export * from './enums';
export type User = Prisma.UserModel;
export type Channel = Prisma.ChannelModel;
export type Message = Prisma.MessageModel;
export type ChannelMember = Prisma.ChannelMemberModel;
export type FriendShipRequest = Prisma.FriendShipRequestModel;
